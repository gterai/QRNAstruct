#!/usr/bin/perl -w

use strict;
use FileHandle;
use Cwd;

sub sum(@){
    my $sum;
    
    for(my $i = 0; $i <= $#_; $i++){
	$sum += $_[$i];
    }
    
    return $sum;
    
}

sub mean(@){
    my $sum;
    
    for(my $i = 0; $i <= $#_; $i++){
	$sum += $_[$i];
	#print "$_[$i]\n";
    }
    #print "$sum\n";
    return $sum/($#_ + 1);
    
}

sub median($){
#    my $elm = int((scalar @{$_[0]})/2);
    my $elm = scalar @{$_[0]};
    
    my @sorted = sort {$a <=> $b} @{$_[0]};
    if($elm % 2 != 0){ # odd number
	my $pos = int($elm/2) + 1; # 1-based position
#	print "ODD:$elm\t$pos(1-based)\n";
	return $sorted[$pos - 1]; 
    }
    else{ # even number
	my $pos = $elm/2; # 1-based position
#	print "EVEN:$elm\t$pos(1-based)\n";
	return ($sorted[$pos-1]+$sorted[$pos])/2; # 0-based position
    }
    
}


sub sd($@){
    my $mean = shift;
    my $sum;
    
    for(my $i = 0; $i <= $#_; $i++){
	$sum += ($_[$i] - $mean) * ($_[$i] - $mean);
    }
    
    return sqrt($sum/($#_ + 1));
    
}

sub normVec(@){
    my @a;
    my $mean = mean(@_);
    my $sd   = sd($mean, @_);
    foreach my $val (@_){
	push(@a, (($val - $mean)/$sd));
    }
    return @a;
}


#                 $offset = 0;
#while($offset < length $output_seq){
#    print substr($output_seq, $offset, 60),"\n";
#    $offset += 60;
#}

sub getSeqLen(%){
    my %s = @_;
    my %h;
    
    foreach my $id (keys %s){
	$h{$id} = length $s{$id};
    }
    
    return %h;
}


sub readSequenceArray_ref(){
    my ($delim, @id, @seq);
    
    if($#_ == 0){
	$delim = ' ';
    }
    else{
	$delim = "$_[1]";
    }
    
    my $fh;
    if($_[0] =~ /\.gz$/){
	$fh = new FileHandle("zcat $_[0]|") || die "Can't open $_[0] ($!)\n";
    }
    else{
	$fh = new FileHandle($_[0]) || die "Can't open $_[0] ($!)\n";;
    }
    my $sid = -1;
    while(<$fh>){
	chomp;
	next if(/^\#/);
	if(/^>(.+)$/){
	    $sid++;
	    my ($id) = split /$delim/, $1;
	    $id[$sid] = $id;
	}
	else{
	    $seq[$sid] .= $_;
	}
    }
    $fh->close();
    
    return \@id, \@seq;
}


sub readSequence_ref(){
    my ($delim, $id, %hash);
    
    if($#_ == 0){
	$delim = ' ';
    }
    else{
	$delim = "$_[1]";
    }
    
    my $fh;
    if($_[0] =~ /\.gz$/){
	$fh = new FileHandle("zcat $_[0]|") || die "Can't open $_[0] ($!)\n";;
    }
    else{
	$fh = new FileHandle($_[0]) || die "Can't open $_[0] ($!)\n";;
    }
    while(<$fh>){
	chomp;
	next if(/^\#/);
	if(/^>(.+)$/){
	    #print "=$_\n";
	    #print "=$1\n";
	    #print STDERR "$delim\n";
	    ($id) = split /$delim/, $1;
	}
	else{
	    $hash{$id} .= $_;
	}
    }
    $fh->close();
    
    return \%hash;
    
}

sub readSequence(){
    #my $href = readSequence_ref($_[0],$_[1]);
    my $href;
    if(defined $_[1]){
	$href = &readSequence_ref($_[0], $_[1]);
    }
    else{
	$href = &readSequence_ref($_[0]);
    }
    
    return %{$href};
}

sub readSequenceTU(){
    #my $href = readSequence_ref($_[0],$_[1]);
    my $href;
    if(defined $_[1]){
	$href = &readSequence_ref($_[0], $_[1]);
    }
    else{
	$href = &readSequence_ref($_[0]);
    }
    
    return &SeqTU($href);
}

sub SeqTU{
    my %h;
    
    foreach my $id (keys %{$_[0]}){
	$h{$id} = $_[0]->{$id};
	$h{$id} =~ tr/Tt/Uu/;
    }
    
    return %h;
}


sub readFastQ_ref(){
    my ($id, %hash);
    
    my $fh;
    if($_[0] =~ /\.gz$/){
	$fh = new FileHandle("zcat $_[0]|") || die "Can't open $_[0] ($!)\n";;
    }
    else{
	$fh = new FileHandle($_[0]) || die "Can't open $_[0] ($!)\n";;
    }
    while(<$fh>){
	chomp;
	if(/^\@(\S+)/){
	    $id = $1;
	    chomp($_ = <$fh>);
	    $hash{$id} = $_;
	    chomp($_ = <$fh>); # + line
	    if(!/^\+/){
		die "Unexpected line $_ for $id\n";
	    }
	    chomp($_ = <$fh>); # quality score
	}
	else{
	    die "Unexpected line $_\n";
	}
    }
    $fh->close();
    
    return \%hash;
    
}

sub print_fasta($$$){
    my $id = $_[0];
    my $seq = $_[1];
    my $w = $_[2];

    print ">$id\n";
    my $offset = 0;
    while($offset < length $seq){
	
        print substr($seq, $offset, $w),"\n";
	
        $offset += $w;

	
    }
    
}



sub cutSequence($$$$$){
    my $seqdir = $_[0];
    my $chr = $_[1];
    my $fm = $_[2];
    my $to = $_[3];
    my $str = $_[4];
    my $seq;
    
#    $chr =~ s/^chr//;
#    my $filename = "chr$chr.bare";
    my $filename = "$chr.bare";
    
    my $fh;
    $fh = new FileHandle("$seqdir/$filename") || die "Can't open $seqdir/$filename:$!\n";
    open($fh, "$seqdir/$filename") || die "Can't open $seqdir/$filename:$!\n";
    seek($fh, $fm - 1, 0);
    read($fh, $seq, $to - $fm + 1);
    close($fh);
#    open(FH, "$seqdir/$filename") || die "Can't open $seqdir/$filename:$!\n";
#    seek(FH, $fm - 1, 0);
#    read(FH, $seq, $to - $fm + 1);
#    close(FH);
    
#    if($str eq '+'){
    if($str eq '+' ||
       $str eq '.'){
        # skip
    }
    elsif($str eq '-'){
        $seq = reverse $seq;
#        $seq =~ tr /ATGC/TACG/;
        $seq =~ tr /ATGCatgc/TACGtacg/;
    }
    else{
#        carp "Unrecognized strand orientation ($str)\n";
#	die;
        die "Unrecognized strand orientation ($str)\n";
    }
    
    return $seq;
    
}


sub cutSequence_notrim($$$$$){
    my $seqdir = $_[0];
    my $chr = $_[1];
    my $fm = $_[2];
    my $to = $_[3];
    my $str = $_[4];
    my $seq;
    
    my $filename = "$chr.bare";
    
    open(FH, "$seqdir/$filename") || die "Can't open $seqdir/$filename:$!\n";
    seek(FH, $fm - 1, 0);
    read(FH, $seq, $to - $fm + 1);
    close(FH);
    
#    if($str eq '+'){
    if($str eq '+' ||
       $str eq '.'){
        # skip
    }
    elsif($str eq '-'){
        $seq = reverse $seq;
#        $seq =~ tr /ATGC/TACG/;
        $seq =~ tr /ATGCatgc/TACGtacg/;
    }
    else{
#        carp "Unrecognized strand orientation ($str)\n";
#	die;
        die "Unrecognized strand orientation ($str)\n";
    }
    
    return $seq;
    
}




sub readClustalW($){
    my %h;
    
    my $fh = new FileHandle ($_[0]) || die;
    my $header = <$fh>; # header
    unless($header =~ /^CLUSTAL W/){
	die "Please check file format. Your input may not be clustal format.\n";
    }
    while(<$fh>){
	chomp;
	s/^\s*//;
	
	next if(/^$/);
	next if(/^\*/);
	
	my ($name, $seq) = split /\s+/;
	
	$h{$name} .= $seq;
	
    }
    $fh->close();
    
    return %h;
    
}

sub outputClustalW(%){
    my %h = @_;
    # mimics clustalw format for RNAz
    print "CLUSTAL W\n";
    print "\n";
    foreach my $id (keys %h){
#	printf "$id\t$h{$id}\n";
	print "$id\t$h{$id}\n";
    }
    print "\n";

}

sub outputClustalW_File($%){
    my $o = shift;
    my %h = @_;

    open(OALN, ">$o") || die;
    
    # mimics clustalw format for RNAz
    print OALN "CLUSTAL W\n";
    print OALN "\n";
    foreach my $id (keys %h){
	print OALN "$id\t$h{$id}\n";
    }
    print OALN "\n";
    
    close(OALN);
    
}

sub outputFasta($%){
    my $outfile = shift;
    my %h = @_;
    
    open(OUT, ">$outfile") || die "Can't create $outfile: $!\n";;
    foreach my $id (keys %h){
	print OUT ">$id\n$h{$id}\n";
    }
    close(OUT);
    
}

sub trans2Darray(@){
    my @s = @_;
    my @s2;
    for(my $j = 0; $j <= $#{$s[0]}; $j++){
	for(my $i = 0; $i <= $#s; $i++){
	    $s2[$j][$i] = $s[$i][$j];
	}
    }
    
    return @s2;
}


sub calcMeanPairwiseIdentity(%){
    my @seq = @_;
    my ($sum_ident, $n);
    
    for (my $i = 0; $i <= $#seq; $i++){
	for (my $j = $i + 1; $j <= $#seq; $j++){
	    
	    
	    $sum_ident += &Ident($seq[$i], $seq[$j]);
	    $n++;
	    
	}
    }
    
    return $sum_ident/$n;
	
}


sub Ident($$){
    
    my @a = split '', $_[0];
    my @b = split '', $_[1];
    
    my ($n, $m);
    
    $m = 0;
    $n = 0;
    
    if($#a != $#b){
	die "different length of sequence.\n";
    }
    
    for(my $i = 0; $i <= $#a; $i++){
	next if($a[$i] =~ /[^ATGCatgc]/ && $b[$i] =~ /[^ATGCatgc]/);
	#print "$a[$i] $b[$i]\n";
	$n++;
	if($a[$i] eq $b[$i]){
	    $m++;
	    #print "$a[$i] $b[$i]\n";
	}
	
    }
    
    if($n == 0){
	return 0;
    }
    else{
	#print $m/$n, "\n";
	return $m/$n;
    }
    
}


sub fisher_yates_shuffle {
    my $array = shift;
    my $i;

    for($i = @$array; --$i; ){

        my $j = int rand ($i + 1);
        next if $i == $j;
        @$array[$i, $j] = @$array[$j, $i];

    }

}


sub covariance {
    my ($array1ref, $array2ref) = @_;
    my ($i, $result);
    for($i = 0; $i < @$array1ref; $i++){
	$result += $array1ref->[$i] * $array2ref->[$i];
    }
    
    $result /= @$array1ref;
    $result -= mean(@$array1ref) * mean(@$array2ref);
    return $result; # added in 20200625
}

sub correlation {
    my ($array1ref_ini, $array2ref_ini) = @_;
    # ここで欠損値を取り除く作業を加える。
    
    if($#{$array1ref_ini} != $#{$array2ref_ini}){
	die "Different number of array elements $#{$array1ref_ini} != $#{$array2ref_ini}\n";
    }
    
    # 欠損値にはNDを入れる。
    my (@a1, @a2);
    for(my $i = 0; $i <= $#{$array1ref_ini}; $i++){
	if(
	   ($array1ref_ini->[$i] ne "ND" && $array1ref_ini->[$i] ne "NA")
	   &&
	   ($array2ref_ini->[$i] ne "ND" && $array2ref_ini->[$i] ne "NA")
	   ){
	    push(@a1, $array1ref_ini->[$i]);
	    push(@a2, $array2ref_ini->[$i]);
	}
    }
    
#    return -2 if($#a1 <= 0); # 2つのデータで重なりが1要素以下だった。    
    return "NA1" if($#a1 <= 0); # 2つのデータで重なりが1要素以下だった。    
    
    my ($array1ref, $array2ref) = (\@a1, \@a2);
    
    my ($sum1, $sum2);
    my ($sum1_squared, $sum2_squared);
    foreach (@$array1ref){ $sum1 += $_; $sum1_squared += $_ ** 2 }
    foreach (@$array2ref)
    { 
	$sum2 += $_; $sum2_squared += $_ ** 2;
#	if($_ eq ''){
#	    #print "@$array1ref\n";
#	    print join ":", @$array2ref;
#	    exit(0);
#	}
    }
    
#    print covariance($array1ref, $array2ref), "::TEST\n";
#    my $cov = covariance($array1ref, $array2ref);
    my $d1 = (@$array1ref * $sum1_squared) - ($sum1 ** 2);
    my $d2 = (@$array1ref * $sum2_squared) - ($sum2 ** 2);
    return "NA2" if($d1 * $d2 == 0); # どちらかのデータがすべて同じ値（＝分散0)
#    my $test = covariance($array1ref, $array2ref);
    my $chk = ((@$array1ref * $sum1_squared) - ($sum1 ** 2)) *
	((@$array1ref * $sum2_squared) - ($sum2 ** 2));
    return "NA3" if($chk < 0); # denominator is negative 
#    exit(0);
    return (@$array1ref ** 2) * covariance($array1ref, $array2ref) / 
	sqrt(((@$array1ref * $sum1_squared) - ($sum1 ** 2)) * 
	     ((@$array1ref * $sum2_squared) - ($sum2 ** 2)));
    
}

sub max($$){
    
    return $_[0] if($_[0] > $_[1]);
    return $_[1];
    
}

sub min($$){
    
    return $_[0] if($_[0] < $_[1]);
    return $_[1];
    
}


sub readHash($$){
    my %h;
    
    my $p = 0;
    open(FH, $_[0]) || die "$! $_[0]";
    while(<FH>){
	next if(/^\#/);
	chomp;
	$p++;
	
	if(s/\r$// && $p == 1){
	    print STDERR "\\r is excluded.\n";
	}
	
	my (@a) = split /\t/;
	if(!defined $h{$a[0]}){
	    if(defined $_[1] && $_[1] eq "r"){
		$h{$a[1]} = $a[0];
	    }
	    else{
		$h{$a[0]} = $a[1];		
	    }
	}
	else{
	    warn "key $a[0] is already defined.\n";
	}
	
    }
    close(FH);
    return %h;   
}

sub readHash_rev($){
    my %h;
    
    open(FH, $_[0]) || die "$! $_[0]";
    while(<FH>){
	next if(/^\#/);
	chomp;
	
	my (@a) = split /\t/;
	if(!defined $h{$a[1]}){
	    $h{$a[1]} = $a[0];
	}
	else{
	    warn "key $a[1] is already defined.\n";
	}
    }
    close(FH);
    return %h;   
}

sub readList($){
    my %h;

    my $fh;
    if($_[0] =~ /\.gz$/){
#	open(FH, "zcat $_[0]|") || die "$! $_[0]";
	$fh = new FileHandle("zcat $_[0]|") || die "$! $_[0]";
    }
    else{
#	open(FH, $_[0]) || die "$! $_[0]";
	$fh = new FileHandle($_[0]) || die "$! $_[0]";
    }
#    while(<FH>){
    while(<$fh>){
	next if(/^\#/);
	chomp;
	
	my (@a) = split /\s+/;
	$h{$a[0]} = 1;
    }
#    close(FH);
    $fh->close();
    
    return %h;   
}

sub readArray($){
    my @a;
    
    my $fh = new FileHandle($_[0]) || die "$! $_[0]";
    while(<$fh>){
	next if(/^\#/);
	chomp;
	
	my (@b) = split /\t/;
	push(@a, $b[0]);
   }
    $fh->close();
    return @a;
}

#sub List2Array($){
#    my @A;
#    
#    open(FH, $_[0]) || die "$! $_[0]";
#    while(<FH>){
#	next if(/^\#/);
#	chomp;
#	
#	my (@a) = split /\t/;
#	push(@A, $a[0]);
#   }
#    close(FH);
#    return @A;
#}

sub chkFullPath($){

    if($_[0] !~ /^\//){
        die "Please input an absolute path instead of $_[0]\n";
    }

    return $_[0];
}


sub setChrLen_hg17{
    my %chrLen;
    $chrLen{chr1} = 245522847;
    $chrLen{chr2} = 243018229;
    $chrLen{chr3} = 199505740;
    $chrLen{chr4} = 191411218;
    $chrLen{chr5} = 180857866;
    $chrLen{chr6} = 170975699;
    $chrLen{chr7} = 158628139;
    $chrLen{chr8} = 146274826;
    $chrLen{chr9} = 138429268;
    $chrLen{chr10} = 135413628;
    $chrLen{chr11} = 134452384;
    $chrLen{chr12} = 132449811;
    $chrLen{chr13} = 114142980;
    $chrLen{chr14} = 106368585;
    $chrLen{chr15} = 100338915;
    $chrLen{chr16} = 88827254;
    $chrLen{chr17} = 78774742;
    $chrLen{chr18} = 76117153;
    $chrLen{chr19} = 63811651;
    $chrLen{chr20} = 62435964;
    $chrLen{chr21} = 46944323;
    $chrLen{chr22} = 49554710;
    $chrLen{chrX} = 154824264;
    $chrLen{chrY} = 57701691;
    return %chrLen;
}


sub setChrLen_hg18{
    my %chrLen;
    $chrLen{chr1} = 247249719;
    $chrLen{chr2} = 242951149;
    $chrLen{chr3} = 199501827;
    $chrLen{chr4} = 191273063;
    $chrLen{chr5} = 180857866;
    $chrLen{chr6} = 170899992;
    $chrLen{chr7} = 158821424;
    $chrLen{chr8} = 146274826;
    $chrLen{chr9} = 140273252;
    $chrLen{chr10} = 135374737;
    $chrLen{chr11} = 134452384;
    $chrLen{chr12} = 132349534;
    $chrLen{chr13} = 114142980;
    $chrLen{chr14} = 106368585;
    $chrLen{chr15} = 100338915;
    $chrLen{chr16} = 88827254;
    $chrLen{chr17} = 78774742;
    $chrLen{chr18} = 76117153;
    $chrLen{chr19} = 63811651;
    $chrLen{chr20} = 62435964;
    $chrLen{chr21} = 46944323;
    $chrLen{chr22} = 49691432;
    $chrLen{chrX} = 154913754;
    $chrLen{chrY} = 57772954;
    $chrLen{chrM} = 16571;
    return %chrLen;
}

sub setChrLen_hg38{
    my %chrLen;

    $chrLen{chr1}  = 248956422;
    $chrLen{chr10} = 133797422;
    $chrLen{chr11} = 135086622;
    $chrLen{chr12} = 133275309;
    $chrLen{chr13} = 114364328;
    $chrLen{chr14} = 107043718;
    $chrLen{chr15} = 101991189;
    $chrLen{chr16} =  90338345;
    $chrLen{chr17} =  83257441;
    $chrLen{chr18} =  80373285;
    $chrLen{chr19} =  58617616;
    $chrLen{chr2} =  242193529;
    $chrLen{chr20} = 64444167;
    $chrLen{chr21} = 46709983;
    $chrLen{chr22} = 50818468;
    $chrLen{chr3} = 198295559;
    $chrLen{chr4} = 190214555;
    $chrLen{chr5} = 181538259;
    $chrLen{chr6} = 170805979;
    $chrLen{chr7} = 159345973;
    $chrLen{chr8} = 145138636;
    $chrLen{chr9} = 138394717;
    $chrLen{chrX} = 156040895;
    $chrLen{chrY} = 57227415;

    return %chrLen;
}

sub setChrLen_hg18_random{
    my %chrLen;
    $chrLen{chr10_random} = 113275;
    $chrLen{chr11_random} = 215294;
    $chrLen{chr13_random} = 186858;
    $chrLen{chr15_random} = 784346;
    $chrLen{chr16_random} = 105485;
    $chrLen{chr17_random} = 2617613;
    $chrLen{chr18_random} = 4262;
    $chrLen{chr19_random} = 301858;
    $chrLen{chr1_random} = 1663265;
    $chrLen{chr21_random} = 1679693;
    $chrLen{chr22_random} = 257318;
    $chrLen{chr2_random} = 185571;
    $chrLen{chr3_random} = 749256;
    $chrLen{chr4_random} = 842648;
    $chrLen{chr5_random} = 143687;
    $chrLen{chr6_random} = 1875562;
    $chrLen{chr7_random} = 549659;
    $chrLen{chr8_random} = 943810;
    $chrLen{chr9_random} = 1146434;
    $chrLen{chrX_random} = 1719168;
    $chrLen{chrM} = 16571;
    return %chrLen;
}

sub setChrLen_hg18_all{
    my %chrLen;
    $chrLen{chr1} = 247249719;
    $chrLen{chr2} = 242951149;
    $chrLen{chr3} = 199501827;
    $chrLen{chr4} = 191273063;
    $chrLen{chr5} = 180857866;
    $chrLen{chr6} = 170899992;
    $chrLen{chr7} = 158821424;
    $chrLen{chr8} = 146274826;
    $chrLen{chr9} = 140273252;
    $chrLen{chr10} = 135374737;
    $chrLen{chr11} = 134452384;
    $chrLen{chr12} = 132349534;
    $chrLen{chr13} = 114142980;
    $chrLen{chr14} = 106368585;
    $chrLen{chr15} = 100338915;
    $chrLen{chr16} = 88827254;
    $chrLen{chr17} = 78774742;
    $chrLen{chr18} = 76117153;
    $chrLen{chr19} = 63811651;
    $chrLen{chr20} = 62435964;
    $chrLen{chr21} = 46944323;
    $chrLen{chr22} = 49691432;
    $chrLen{chrX} = 154913754;
    $chrLen{chrY} = 57772954;
    $chrLen{chr10_random} = 113275;
    $chrLen{chr11_random} = 215294;
    $chrLen{chr13_random} = 186858;
    $chrLen{chr15_random} = 784346;
    $chrLen{chr16_random} = 105485;
    $chrLen{chr17_random} = 2617613;
    $chrLen{chr18_random} = 4262;
    $chrLen{chr19_random} = 301858;
    $chrLen{chr1_random} = 1663265;
    $chrLen{chr21_random} = 1679693;
    $chrLen{chr22_random} = 257318;
    $chrLen{chr2_random} = 185571;
    $chrLen{chr3_random} = 749256;
    $chrLen{chr4_random} = 842648;
    $chrLen{chr5_random} = 143687;
    $chrLen{chr6_random} = 1875562;
    $chrLen{chr7_random} = 549659;
    $chrLen{chr8_random} = 943810;
    $chrLen{chr9_random} = 1146434;
    $chrLen{chrX_random} = 1719168;
    $chrLen{chrM} = 16571;
    return %chrLen;
}


sub setChrOrder{
    my %h;
    $h{chr1} = 1;
    $h{chr2} = 2;
    $h{chr3} = 3;
    $h{chr4} = 4;
    $h{chr5} = 5;
    $h{chr6} = 6;
    $h{chr7} = 7;
    $h{chr8} = 8;
    $h{chr9} = 9;
    $h{chr10} = 10;
    $h{chr11} = 11;
    $h{chr12} = 12;
    $h{chr13} = 13;
    $h{chr14} = 14;
    $h{chr15} = 15;
    $h{chr16} = 16;
    $h{chr17} = 17;
    $h{chr18} = 18;
    $h{chr19} = 19;
    $h{chr20} = 20;
    $h{chr21} = 21;
    $h{chr22} = 22;
    $h{chrX} = 23;
    $h{chrY} = 24;
    $h{chrM} = 25;
    return %h;
}


sub valStr($){
    if($_[0] eq '+' || $_[0] eq '-'){
	return $_[0];
    }
    
    die "Unexpected strand ($_[0]) in valStr\n";
}


sub revComp($){
    my $seq = $_[0];
    $seq = reverse $seq;
    $seq =~ tr/ATGCUatgcu/TACGAtacga/;
    
    return $seq;
}

sub revCompNRY($){
    my $seq = $_[0];
    if($seq !~ /([ATGCNRY])/){
	die "Motif contains invalid letter ($1).\n";
    }
    
    $seq = reverse $seq;
    $seq =~ tr/ATGCRY/TACGYR/; # N is not converted
    
    return $seq;
}

sub Comp($){
    my $seq = $_[0];
    $seq =~ tr/ATGCUatgcu/TACGAtacga/;
    
    return $seq;
}


sub tempdir {
    my $cur_dir = getcwd();
    my $UID = int( rand(999) );    # for temporary file
    my $tmpfname = sprintf( "%s/%6d_%03d_%03d", $cur_dir, time, $$, $UID);
    return $tmpfname;
}

sub numKey($) {
    my @tmp = keys %{$_[0]};
    return $#tmp + 1;
}

sub calcGC{
    
    my $gc = 0;
    for(my $i = 0; $i <= $#_; $i++){
	$gc++ if($_[$i] =~ /^[GCgc]$/);
    }
    
    return $gc/scalar(@_);
}
    
sub readOneSeq{
    my $seq;
    
    my $fh = new FileHandle($_[0]) || die;
    
    chomp ($_ = <$fh>);
    if(!/^>/){
        die "Unexpected fasta header $_\n";
    }
    while(<$fh>){
        chomp;

        if(/^>/){
            die "Multifasta format is prohibitted ($_)\n";
        }
        
        $seq .= $_;
        
        
    }
    
    $fh->close();
    
    
    return $seq;
}

sub readOneSeqID($){
    my $seq;
    
    my $fh = new FileHandle($_[0]) || die;
    
    chomp ($_ = <$fh>);
    if(!/^>(\S+)/){
        die "Unexpected fasta header $_\n";
    }
    my $id = $1;
    while(<$fh>){
        chomp;

        if(/^>/){
            die "Multifasta format is prohibitted ($_)\n";
        }
        
        $seq .= $_;
        
        
    }
    
    $fh->close();
    
    
    return $id, $seq;
}

sub readFstSeq($){
    my $seq;
    
    my $fh = new FileHandle($_[0]) || die;
    
    chomp ($_ = <$fh>);
    if(!/^>/){
        die "Unexpected fasta header $_\n";
    }
    while(<$fh>){
        chomp;

        if(/^>/){
	    last;
        }
        
        $seq .= $_;
        
        
    }
    
    $fh->close();
    
    
    return $seq;
}

sub randomNuc($){
    my $n = $_[0];
    
    if($n <= 0 || $n >= 1000000){
	die "Invalid sequence length ($n)\n";
    }
    
    my $seq;
    for(my $i = 0; $i < $n; $i++){
	my $j = int(rand(4));
	
	if($j < 1){
	    $seq .= "A";
	}
	elsif($j < 2){
	    $seq .= "C";
	}
	elsif($j < 3){
	    $seq .= "G";
	}
	else{
	    $seq .= "T";
	}
    }
    
    return $seq;
}


sub HD($$){
    my ($s1_aref, $s2_aref) = @_;
    
    if($#{$s1_aref} != $#{$s2_aref}){
	die "The length of an input sequence pair is not the same.\n";
    }
    
    my $hd = 0;
    for(my $i = 0; $i <= $#{$s1_aref}; $i++){
	$hd++ if($s1_aref->[$i] ne $s2_aref->[$i]);
    }
    
    return $hd;
}

sub pearson($$){
    return correlation($_[0], $_[1]);
}
sub spearman($$){
    my @r1 = convert2rank(@{$_[0]});
    my @r2 = convert2rank(@{$_[1]});
    return correlation(\@r1, \@r2);
}

sub convert2rank(@){
    my %h;
    for(my $i = 0; $i <= $#_; $i++){
	$h{$i} = $_[$i];
    }
    
    my @order = sort {$h{$a} <=> $h{$b}} keys %h;
    # check the same values
    {
	for(my $i = 0; $i < $#_; $i++){
	    if($h{$order[$i]} == $h{$order[$i+1]}){
		print STDERR "Warning: the data contains the same values ($h{$order[$i]})\n";
		last;
	    }
	}
    }

    my @rank;
    for(my $r = 0; $r <= $#order; $r++){
	$rank[$order[$r]] = $r;
    }


    return @rank;

}

sub transposeSeq{
    my $seq_aref = $_[0];
    my @a;
    
    foreach my $seq (@{$seq_aref}){
	my @s = split "", $seq;
	for(my $i = 0; $i <= $#s; $i++){
	    $a[$i] .= $s[$i]; 
	}
    }
    
    return \@a;
}

1;

