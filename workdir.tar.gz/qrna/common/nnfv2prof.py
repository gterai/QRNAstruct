# -*- coding: utf-8 -*-

import os
import sys
import argparse
#sys.path.append("/qrna/common")
#import basic
#from Bio import SeqIO
#from Bio.SeqRecord import SeqRecord
#import re
#import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#from sklearn import svm
#from scipy.stats import pearsonr
#import RNA

def main(args: dict):
    
    data = pd.read_table(args.nnfv_file)
    #print(data)
    columns = data.columns
    nfv = len(columns) - 2
    if (nfv % 6 != 0):
        print("Number of features (%d) must be muptiple of 6" % nfv, file=sys.stderr)
        exit(1)
    lseq = int(nfv / 6)

    mprof = {}
    for stype in ('L', 'R', 'H', 'B', 'I', 'E'):
        mprof[stype] = ['' for i in range(lseq)] 

    for c in columns[2:]:
        #print(list(data[c]))
        mean = np.mean(list(data[c]))
        (stype, pos) = (c[0], int(c[1:]))
        #print (c, mean)
        mprof[stype][pos-1] = float(mean)

    for stype in ('L', 'R', 'H', 'B', 'I', 'E'):
        plt.plot(mprof[stype])
    plt.legend(['L', 'R', 'H', 'B', 'I', 'E'])
    plt.savefig("tmp.pdf")
        
if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('nnfv_file', help='nnfv.txt file')
    args = parser.parse_args()

    main(args)
    
