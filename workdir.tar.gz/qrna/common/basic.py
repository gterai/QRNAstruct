import sys
import re

def readSequence(fname):
    d = {}
    #dup = {}

    with open(fname, 'r') as fh:
        id = ''
        for line in fh.readlines():
            line = line.strip()
            
            if line[0] == '>': # header
                id = line[1:].split(' ')[0]
                #if id in dup:
                #    print("{0} found more than once".format(id))
                   
            else:
                if id in d:
                    d[id] += line
                else:
                    d[id] = line

    return d


def readOneSeq(fname):
    seq = ''
    
    with open(fname, 'r') as fh:
        line = fh.readline()
        if line[0] != '>': # header
            print("Unexpected header in {0}".format(line),file=sys.stderr)
            exit(0)

        for line in fh.readlines():
            line = line.strip()
            
            if line[0] == '>': # header
                print("Multifasta format is prohibitted ({0})".format(id),file=sys.stderr)
                exit(0)
            seq += line

    return seq


def readOneSeqID(fname):
    seq = ''
    
    with open(fname, 'r') as fh:
        line = fh.readline().strip()
        m = re.match(r'>(\S+)',line)
        if m is None:
            print("Unexpected header in {0} ({1})".format(fname,line),file=sys.stderr)
            exit(0)
        else:
            id = m.group(1)
            
        for line in fh.readlines():
            line = line.strip()
            
            if line[0] == '>': # header
                print("Multifasta format is prohibitted ({0})".format(id),file=sys.stderr)
                exit(0)
            seq += line

    return [id, seq]

def readHash(fname):
    d = {}
    
    p = 0
    with open(fname, 'r') as fh:

        for line in fh.readlines():
            if(line[0] == '#'):
                continue

            line = line.strip()
            key_val = line.split("\t")

            d[key_val[0]] = key_val[1]
            
            p += 1
        
        

    return d
        
