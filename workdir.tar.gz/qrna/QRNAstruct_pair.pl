#!/usr/bin/perl -w

use strict;
use FileHandle;
use Getopt::Long;
use FindBin;

my ($D, $O, $I);
GetOptions('I'=>\$I, 'D=s'=>\$D, 'O=s'=>\$O);

unless($#ARGV == 1){ 
    die "usage: $0 [Alpha] [nCPU] (-I -O)\n";
}

my $BaseDir = $FindBin::Bin;

require "$BaseDir/common/basic.pl";

my $DataDir = "$BaseDir/data/"; # これが味噌。Dokerではここがマウントポイントになる。
# 普段のスクリプトとしては、-D -Oを指定して使う。
# Dockerの時は、dataが入ったディレクトリを-vでマウント。-Oを使うこともできる。-Dは使ってはいけない。
# $BaseDirが/wdirの時には-Dを無効にした方が良いかも。
$DataDir = $D if(defined $D);

my $rnaX_file        = "$DataDir/seqX.fa";
my $train_file_org   = "$DataDir/seqY.fa";
my $id2exp_file_raw  = "$DataDir/act.txt";
my $OutDir           = "$DataDir/out"; $OutDir = "$DataDir/$O" if(defined $O);
my $Alp              = $ARGV[0];
my $id2PF_file       = "$OutDir/id2PF.txt";
my $id2prof_file     = "$OutDir/id2prof.txt";
my $nnfv_file        = "$OutDir/nnfv.txt";
my $wopt_file        = "$OutDir/w_opt.txt";
my $matP_image_file  = "$OutDir/w_opt_matP.png";
my $matX_image_file  = "$OutDir/w_opt_matX.png";
my $matY_image_file  = "$OutDir/w_opt_matY.png";
#my $wfin_file        = "$OutDir/w_fin.txt";

my ($com, $msg);
if(defined $I){
    if(!-e $nnfv_file){
	die "nnfv_file was not found in the output directory.\n";
    }
}
else{
    # check input files
    if(!-e $rnaX_file){
	die "seqX.fa was not found in the data directory.\n";
    }
    if(!-e $train_file_org){
	die "seqY.fa was not found in the data directory.\n";
    }
    if(!-e $id2exp_file_raw){
	die "act.txt was not found in the data directory.\n";
    }
}

if($Alp <= 0){
    print STDERR "Alpha must be positive integer.\n";
    exit(0);
}

my $nCPU = &chkCPU($ARGV[1]);

# check workdir
if(-d $OutDir){
    # skip
}
else{
    `mkdir $OutDir`;
}

if(!defined $I){
    # check input data
    my ($id_aref, $seq_aref) = &readSequenceArray_ref($train_file_org);
    my ($rnaX_seq) = &readOneSeq($rnaX_file);
    &chkLen($seq_aref);
    my %id2exp_raw = &readHash($id2exp_file_raw);
    &chkID($id_aref, \%id2exp_raw);
    
    # get length of input RNA
    my ($lX, $lY) = (length($rnaX_seq), length($seq_aref->[0]));
    
    # calculate the position-specific features for each training data
    #`perl $BaseDir/pair/calcCPF.pl $train_file_org $rnaX_file $nCPU $id2PF_file $id2prof_file` if(!defined $I);
    $msg = "calculating the position-specific structural features";
    $com = "perl $BaseDir/pair/calcCPF.pl $train_file_org $rnaX_file $nCPU $id2PF_file $id2prof_file";
    &run_command($com, $msg);
    
    # create a table of feature vectors and normalized activity values
    #`python3 $BaseDir/pair/makeDataNexp.py $id2exp_file_raw $id2prof_file $lX $lY > $nnfv_file` if(!defined $I);
    $msg = "creating a table of feature vectors and normalized activity values";
    $com = "python3 $BaseDir/pair/makeDataNexp.py $id2exp_file_raw $id2prof_file $lX $lY > $nnfv_file";
    &run_command($com, $msg);

}
else{
    print "The parameter \"nCPU = $nCPU\" is ignored because the calculation of the feature vectors is skipped.\n";
}
# run Ridge regression
# `python3 $BaseDir/pair/runRidge.py $nnfv_file $Alp $wopt_file`;
$msg = "running Ridge regression";
$com = "python3 $BaseDir/pair/runRidge.py $nnfv_file $Alp $wopt_file";
&run_command($com, $msg);

# make image files of the optimized weights
#`python3 pair/makeHeatmap.py $wopt_file $matP_image_file $matX_image_file $matY_image_file`;
$msg = "making heatmap";
$com = "python3 pair/makeHeatmap.py $wopt_file $matP_image_file $matX_image_file $matY_image_file";
&run_command($com, $msg);


sub run_command{
    print "$msg...";
    `$_[0]`;
    print "finished\n";

}


sub writeW{
    my ($w_file, $w_aref) = @_;
    my $ofh = new FileHandle(">$w_file") || die;
    print $ofh "wa\t$w_aref->[0]\n";
    print $ofh "wb\t$w_aref->[1]\n";
    for(my $i = 2; $i <= $#{$w_aref}; $i++){
	my $idx = $i - 2;
	print $ofh "w$idx\t$w_aref->[$i]\n";
    }
    $ofh->close();
}

sub chkCPU{
    my $n = $_[0];
    
    if($n =~ /[^\d]/){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n < 1){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n > 50){
	die "nCPU ($n) is too large.\n";
    }
    
    return $n;
}

sub chkLen
{
    my $s_aref = $_[0];
    my $l = length($s_aref->[0]);
    for(my $i = 1; $i <= $#{$s_aref}; $i++){
        my $ll = length($s_aref->[$i]);
        if($l != $ll){
            die "Sequences with the different lengths were found.\n";
        }
    }
    # check ok
}

sub chkID{
    my ($i_aref, $i2e_href) = @_;
    foreach my $id (@{$i_aref}){
        if(!defined $i2e_href->{$id}){
            die "Activity value of $id is not defined.\n";
        }
    }

}




