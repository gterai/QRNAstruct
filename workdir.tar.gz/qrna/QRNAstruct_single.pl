#!/usr/bin/perl -w

use strict;
use FileHandle;
use Getopt::Long;
use FindBin;

my ($O, $D, $I);
my ($SHAPE, $DMS, $SHAPEslope, $SHAPEintercept);
my ($CAPR);
GetOptions('O=s'=>\$O,'D=s'=>\$D, 'I'=>\$I, 
	   'SHAPE'=>\$SHAPE, 'SHAPEslope=s'=>\$SHAPEslope, 'SHAPEintercept=s'=>\$SHAPEintercept, 'DMS'=>\$DMS, 'CAPR'=>\$CAPR);

unless($#ARGV == 1){
    die "usage: $0 [Alpha] [nCPU] (-I, -O, --SHAPE, --SHAPEintercept, --SHAPEslope, --DMS)\n";
}

my $BaseDir = $FindBin::Bin;

require "$BaseDir/common/basic.pl";


my $DataDir = "$BaseDir/data/"; # これが味噌。Dokerではここがマウントポイントになる。
# 普段のスクリプトとしては、-D -Oを指定して使う。
# Dockerの時は、dataが入ったディレクトリを-vでマウント。-Oを使うこともできる。-Dは使ってはいけない。
# $BaseDirが/wdirの時には-Dを無効にした方が良いかも。
$DataDir = $D if(defined $D);

my $train_file_org   = "$DataDir/seq.fa";
my $id2exp_file_raw  = "$DataDir/act.txt";
my $probing_file     = "$DataDir/probing.txt";
my $OutDir           = "$DataDir/out"; $OutDir = "$DataDir/$O" if(defined $O);
my $Alp              = $ARGV[0];
#my $wini_file        = "$OutDir/w_ini.txt";
my $id2prof_file     = "$OutDir/id2prof.txt";
my $id2PF_file       = "$OutDir/id2PF.txt";
my $nnfv_file        = "$OutDir/nnfv.txt";
my $wopt_txt_file    = "$OutDir/w_opt.txt";
my $wopt_png_file    = "$OutDir/w_opt.png";

if($Alp <= 0){
    print STDERR "Alpha must be positive integer.\n";
    exit(0);
}

my $nCPU = &chkCPU($ARGV[1]);
# check workdir
if(-d $OutDir){
    #skip
}
else{
    `mkdir $OutDir`;
}

# Probing関連オプションのチェック
if(defined $SHAPE && defined $DMS){
    die "Both --SHAPE and --DMS must not be specified.\n";
}
if(defined $SHAPE && defined $DMS){
    if(defined $SHAPEslope){
	die "Either --SHAPE or --DMS must not be specified if you use --SHAPEslope.\n";
    }
    if(defined $SHAPEintercept){
	die "Either --SHAPE or --DMS must not be specified if you use --SHAPEintercept.\n";
    }
}

my ($com, $msg);
if(!defined $I){
    # check input data
    my ($id_aref, $seq_aref) = &readSequenceArray_ref($train_file_org);
    &chkLen($seq_aref);
    my %id2exp_raw = &readHash($id2exp_file_raw);
    &chkID($id_aref, \%id2exp_raw);
    
    if(!defined $SHAPE && !defined $DMS){
	$msg = "calculating the position-specific structural features";
	$com = "perl $BaseDir/single/calcProfile_cmd.pl $train_file_org $nCPU $id2PF_file $id2prof_file";
	&run_command($com, $msg);
	
	$msg = "creating a table of feature vectors and normalized activity values";
	$com = "python3 $BaseDir/single/makeDataNexp.py $id2exp_file_raw $id2prof_file > $nnfv_file";
	&run_command($com, $msg);
    }
    else{ # --SHAPE or --DMS was specified
	my $opt = &makeOpt();
	$opt = '' if(defined $CAPR);
	$msg = "calculating the position-specific structural features";
	$com = "perl $BaseDir/single/wrap_CapR.pl $train_file_org $nCPU $id2prof_file \'$opt\'";
	#print "$com\n";
	&run_command($com, $msg);
	$msg = "creating a table of feature vectors and normalized activity values";
	$com = "python3 $BaseDir/single/makeDataNexpCapR.py $id2exp_file_raw $id2prof_file > $nnfv_file";
	&run_command($com, $msg);
    }
}
else{
    print "The parameter \"nCPU = $nCPU\" is ignored because the calculation of the feature vectors is skipped.\n";
}

sub makeOpt(){
    my @a;
    if(defined $SHAPE){
	push(@a, "--SHAPE $probing_file");
    }
    elsif(defined $DMS){
	push(@a, "--DMS $probing_file");
    }

    if(defined $SHAPEslope){
	push(@a, "--SHAPEslope $SHAPEslope");
    }
    
    if(defined $SHAPEintercept){
	push(@a, "--SHAPEintercept $SHAPEintercept");
    }
    
    return join " ", @a;
}

# run Ridge regression
#`python3 $BaseDir/single/runRidge.py $nnfv_file $Alp $wopt_txt_file`;
$msg = "running Ridge regression";
$com = "python3 $BaseDir/single/runRidge.py $nnfv_file $Alp $wopt_txt_file";
&run_command($com, $msg);

# make heatmap
#`python3 $BaseDir/single/makeHeatmap.py $wopt_txt_file $wopt_png_file`;
$msg = "making heatmap";
$com = "python3 $BaseDir/single/makeHeatmap.py $wopt_txt_file $wopt_png_file";
print "$com\n";
&run_command($com, $msg);

sub run_command{
    print "$msg..."; 
    `$_[0]`;
    print "finished\n";

}

sub chkCPU{
    my $n = $_[0];
    
    if($n =~ /[^\d]/){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n < 1){
	die "nCPU must be a positive integer.\n";
    }
    elsif($n > 50){
	die "nCPU ($n) is too large.\n";
    }
    
    return $n;
}

sub chkLen
{
    my $s_aref = $_[0];
    my $l = length($s_aref->[0]);
    for(my $i = 1; $i <= $#{$s_aref}; $i++){
	my $ll = length($s_aref->[$i]);
	if($l != $ll){
	    die "Sequences with the different lengths were found.\n"; 
	}
    }
    # check ok
}

sub chkID{
    my ($i_aref, $i2e_href) = @_;
    foreach my $id (@{$i_aref}){
	if(!defined $i2e_href->{$id}){
	    die "Activity value of $id is not defined.\n";
	}
    }
    
}

