# -*- coding: utf-8 -*-

import sys
sys.path.append("/qrna/common")
import basic
import numpy as np

args = sys.argv

if len(args) != 3:
    print("usage: {0} [act.txt] [id2prof_by_CapR.txt]".format(__file__))
    exit(0)
    
id2act = basic.readHash(args[1])

def main():
    sname2stype = {'dspL':'L','dspR':'R','hairpin':'H','bulge':'B',
                   'internal':'I','external':'E'}
    id2prof = {}
    npos = 0
    with open(args[2], 'r') as fh:
        for line in fh.readlines():
            line = line.strip()
            #print(line)
            if(len(line) == 0):
                # end of entry
                id2prof[ID] = d
            elif(line[0] == '>'):
                ID = line[1:]
                d  = {}
            else:
                elms = line.split(" ")
                if(npos == 0):
                    npos = len(elms[1:])
                else:
                    if(npos != len(elms[1:])):
                        print("Profile length differs in args[2]", file=sys.stderr)
                        exit(0)
                #print(npos)
                #d[elms[0]] = '\t'.join(elms[1:])
                stype = sname2stype[elms[0]]
                d[stype] = '\t'.join(elms[1:])
    
    ids = list(id2prof.keys())
    id2Nact = normAct(id2act, ids)
    
    id2onehot = {}
    for ID in id2Nact:
        id2onehot[ID] = ''
        fv = []
        #for stype in ('dspL','dspR','hairpin','bulge','internal','external'):
        for stype in ('L','R','H','B','I','E'):
            fv.append(id2prof[ID][stype])
        id2onehot[ID] = "\t".join(fv)
    
    # make names
    names = []
    #for stype in ('dspL','dspR','hairpin','bulge','internal','external'):
    for stype in ('L','R','H','B','I','E'):
       for i in range(1, npos+1):
            names.append(stype + '_' + str(i))
    
    # print header
    print("\t".join(['id', 'act'] + names))
    
    for id in id2Nact:
        print("\t".join([id, str(id2Nact[id]), id2onehot[id]]))

#def letters2vec(letters):
#    vec = []
#    for stype in ('L', 'R', 'H', 'B', 'I', 'E'):
#        for elm in letters:
#            if(elm == stype):
#                vec.append('1')
#            else:
#                vec.append('0')
#    return '\t'.join(vec)

    
#def readProf(fname):
#    d = {}
#    names = []
#    get_names = 1
#    with open(fname, 'r') as fh:
#        id = ''
#        values = []
#        for line in fh.readlines():
#            line = line.strip()
#
#            if(line[0:2] == ">>"):
#                id = line[2:]
#            elif(line[0:4] == ">Log"):
#                #print(len(values))
#                d[id] = values
#                values = []
#                get_names = 0
#            elif(line[0] == ">"):
#                type = line[1:]
#            else:
#                pos, val = line.split(":")
#                values.append(val)
#                if get_names:
#                    names.append(type + pos)
#    
#    return d, names

def normAct(id2a, ids): 
    values = []
    for id  in ids:
        values.append(float(id2a[id]))
    
    values.sort()
    #for v in values:
    #    print(v)
    max = values[-1]
    min = values[0]

    d = {}
    for id in ids:
        d[id] = (float(id2a[id]) - min)/(max - min)

    # ここでゼロノーマライズを行う。
    #print(d.values())
    mean = np.mean(list(d.values()))
    
    for id in ids:
        d[id] = d[id] - mean

    return d


main()


