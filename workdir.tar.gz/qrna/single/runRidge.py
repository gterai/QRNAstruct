# -*- coding: utf-8 -*-

import sys
import pandas as pd
import numpy as np
#import math

args = sys.argv

if(len(args) != 4):
    print("usage: {0} [fv.txt] [alpha] [out file name]".format(__file__))
    exit(0)

data_df = pd.read_table(args[1]) 
#print(data_df)

fnames = data_df.columns[2:]
#print(fnames)
#exit(0)

X = data_df[fnames].values 
Y = data_df['act'].values 
#sse = np.mean(Y**2)
#Sdata = np.mean(np.abs(Y))
#Sdata = np.mean(Y)
#print(data_df)
#exit(0)

#from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression

alp = float(args[2])
if(alp > 0):
    model = Ridge(alpha=alp,fit_intercept=False).fit(X, Y)
elif(alp == 0):
    model = LinearRegression(fit_intercept=False).fit(X, Y)
else:
    print("Alpha cannot be negative.", file=sys.stderr)
    exit(0)
    
out_name = args[3]
with open(out_name, mode='w') as f:
    for i in range(len(model.coef_)):
        f.write("w{0}\t{1}\n".format(fnames[i],model.coef_[i]))
        
    #Y2 = model.predict(X)
    #from scipy.stats import pearsonr
    #cor = pearsonr(Y, Y2)

    #    print(alp, cor, ridge.intercept_, file=sys.stderr)
