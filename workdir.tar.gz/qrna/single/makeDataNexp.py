# -*- coding: utf-8 -*-

import sys
sys.path.append("/qrna/common")
import basic
import numpy as np

args = sys.argv

if len(args) != 3:
    print("usage: {0} [act.txt] [id2prof.txt]".format(__file__))
    exit(0)
    
id2act = basic.readHash(args[1])

def main():
    id2prof, names = readProf(args[2])

    ids = id2prof.keys()
    id2Nact = normAct(id2act, ids)
                      
    names_str = "\t".join(names);
    print ("id\tact\t{0}".format(names_str))
    
    for id in id2prof:
        items = []
        items.append(id)
#        items.append(id2act[id])
        items.append(str(id2Nact[id]))
        for i in range(len(id2prof[id])):
            #print(id2prof[id][i])
            items.append(id2prof[id][i])
        items_str = "\t".join(items)
        print(items_str)

def readProf(fname):
    d = {}
    names = []
    get_names = 1
    label2stype = {'dspL':'L','dspR':'R','hairpin':'H','bulge':'B','internal':'I','external':'E'}
    with open(fname, 'r') as fh:
        id = ''
        values = []
        for line in fh.readlines():
            line = line.strip()

            if(line[0:2] == ">>"):
                id = line[2:]
            elif(line[0:4] == ">Log"):
                #print(len(values))
                d[id] = values
                values = []
                get_names = 0
            elif(line[0] == ">"):
                stype = label2stype[line[1:]]
            else:
                pos, val = line.split(":")
                values.append(val)
                if get_names:
                    names.append(stype + '_' + pos)

    return d, names

def normAct(id2a, ids): 
    values = []
    for id  in ids:
        values.append(float(id2a[id]))

    values.sort()
    #for v in values:
    #    print(v)
    max = values[-1]
    min = values[0]

    d = {}
    for id in ids:
        d[id] = (float(id2a[id]) - min)/(max - min)

    # ここでゼロノーマライズを行う。
    #print(d.values())
    mean = np.mean(list(d.values()))
    
    for id in ids:
        d[id] = d[id] - mean

    return d


main()


