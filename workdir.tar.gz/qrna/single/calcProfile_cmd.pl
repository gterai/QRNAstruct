#!/usr/bin/perl -w

use strict;
use FileHandle;
#use Statistics::RankCorrelation;
use IPC::Open2;
use FindBin;
#use File::Basename;

my $ScriptDir = $FindBin::Bin;
my $ContraDir = "$ScriptDir/../single/contrafold.CapR_LR/src/";
#my $ScriptDir = dirname $0;

unless($#ARGV == 3){
    die "usage: $0 [seq.fa] [nCPU] [out1 (id2pf)] [out2 (id2prof)]\n";
}

require "$ScriptDir/../common/basic.pl";
require "$ScriptDir/../common/getEachSize.pl";


my %seq    = readSequence($ARGV[0]);
#my $w_file = $ARGV[1];

#my $nCPU = 50;
#my $nCPU = 25;
my $nCPU = $ARGV[1];
if($nCPU > 50){
    die"uCPU ($nCPU) is too large.\n";
}

# CPU 1-3で計算する配列のIDを求める。
my $cID_href = &getCID();

# 一時ファイルが出来るディレクトリ
#my $tmp_dir = "/data1/terai/"; 
my $tmp_dir = "/tmp/optSingle/"; 
if(! -e $tmp_dir){
    `mkdir $tmp_dir`;
}
#my $tmp_dir = "/home/terai/Rfit/Cambray/script_learn_acc/tmp/";
opendir(D, $tmp_dir) || die "Can't open $tmp_dir\n";
foreach my $file (readdir(D)){
    if($file =~ /^\d+out\d+$/){
	print "$file\n";
	unlink("$tmp_dir/$file");
    }
}


# Forkして子ノードでPFを計算
my @oFiles;
my %ForkReg;
for(my $b = 0; $b < $nCPU; $b++){
    
    my $file_out = $tmp_dir . "$b" . "out$$" . time; # ここでの$$は親プロセスのID
    push(@oFiles, $file_out);
    
  FORK:{
      my $pid;
      if($pid = fork){
	  # parent process
	  $ForkReg{$pid} = 1;
      }
      elsif(defined $pid){
	  # child process
	  
	  #my $tmp_file_in  = $tmp_dir . "in$$" . time;  # ここでの$$は子プロセスのID
	  
	  my @ids = @{$cID_href->[$b]};
	  #my $id2prof_href = &calcPF_in_child(\@ids, $tmp_file_in);
	  &calcPF_in_child(\@ids, $file_out);
	  
	  exit(0); ######### IMPORTANT !!! #################
	  
      }
      elsif($! =~ /No more process/){
	  sleep 5;
	  redo FORK;
      }
      else{
	  die "Can't fork: $!\n";
      }
      
    }
    
}

while(1){
    my @num_proc = keys %ForkReg;
    last if($#num_proc == -1);

    my $end_proc_id = wait;
    
    print STDERR "child process $end_proc_id finished.\n";
    
    unless(defined $ForkReg{$end_proc_id}){
	die "Unknown process id was returned ($end_proc_id).\n";
    }
    else{
	delete $ForkReg{$end_proc_id};
    }
}


open(OUT1, ">$ARGV[2]") || die;
open(OUT2, ">$ARGV[3]") || die;
foreach my $ofile (@oFiles){
    my $id;
    open(FH, "$ofile") || die;
    while(<FH>){
	chomp;
	if(/^>>(\S+)/){
	    $id = $1;
	}
	elsif(/>Log partition coefficient: (\S+)/){
	    my $pf = $1;
	    print OUT1 "$id\t$pf\n";
	}

	print OUT2 "$_\n";
	
    }
    close(FH);
    
}

### delete all temporary files
foreach my $ofile (@oFiles){
    `rm $ofile`;
}



sub calcPF_in_child{
    my %h;
    my @ids     = @{$_[0]};
    my $file_out = $_[1];
    
    open(OUT, ">$file_out") || die;

#    open2(*Reader, *Writer, "/home/terai/my_tools/contrafold_cmd/src/contrafold predict dummy.fa --partition") || die;
#    open2(*Reader, *Writer, "/home/terai/my_tools/contrafold.CapR_LR/src/contrafold predict dummy.fa --posteriors 1e-8 $w_file --cmd") || die;
#    open2(*Reader, *Writer, "$ScriptDir/../single/contrafold.CapR_LR/src/contrafold predict dummy.fa --posteriors 1e-8 $w_file --cmd") || die;
    open2(*Reader, *Writer, "$ContraDir/contrafold predict $ContraDir/dummy.fa --posteriors 1e-8 $ContraDir/dummy.fa --cmd") || die;
    
    foreach my $id (@ids){
	
	my $const;
	for(my $i = 0; $i < length($seq{$id}); $i++){
	    $const .= "\?";
	}
	
#	open(OUT, ">$in_file") || die "Can't open $in_file:$!\n";
#	print OUT ">$id\n";
#	print OUT "$seq{$id}\n";
#	close(OUT);
	
#	my $command_1 = "/home/terai/my_tools/contrafold.dev/src/contrafold_learn predict $in_file --partition --penalty $ARGV[1]";
#	my $fh = new FileHandle("$command_1|") || die;
#	$_ = <$fh>;
#	/^Log partition coefficient for \"[^\"]+\": (\S+)/ || die "Can't parse unrestricted pf from $_";
	
	#print STDERR "TEST:\@$seq{$id}\n";	
	#print STDERR "TEST:\@$const\n";	
	print Writer "\@$seq{$id}\n";	
	print Writer "\@$const\n";	
	
	print OUT ">>$id\n";
	while($_ = <Reader>){
	    print OUT;
	    if(/Log partition coefficient:/){
		last;
	    }
	}
    }
    close(OUT);
}

sub getCID{
    my @a; # an array to be returned

    my @ids = keys %seq;
    my @bin = getEachSize(scalar @ids, $nCPU);

    for(my $b = 0; $b <= $#bin; $b++){

	for(my $j = 0; $j < $bin[$b]; $j++){
	    my $id = pop(@ids);
	    push(@{$a[$b]}, $id);
#	    print "$id\t$b\n";
	}


    }
    
    return \@a;
}
