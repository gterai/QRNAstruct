# coding: utf-8

import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from PIL import Image, ImageFilter

import sys
import math
import re

args = sys.argv

if len(args) != 3:
    print("usage {0}: [w_opt.txt] [output (png)]".format(args[0]))
    exit()

font_scale_m = 3
font_size_s  = 20

stypes    = ["L", "R", "H", "B", "I", "E"]
stype2idx = {"L":0, "R":1, "H":2, "B":3, "I":4, "E":5}
def main():
    
    w, seqlen = readW(args[1])
    xlab = [""] * seqlen
    for i in range(seqlen): 
        if((i+1) % 5 == 0):
            xlab[i] = str(i+1)
        else:
            xlab[i] = ""

    fig_size_x = 25/50 * seqlen
    fig_size_y = 5
    
    sns.set(font_scale=font_scale_m)
    plt.figure(figsize=(fig_size_x, fig_size_y))
    plt.subplots_adjust(left=0.05, right=1.05, bottom=0.20, top=0.95)
    ylab = stypes
    ax = sns.heatmap(w.transpose(), cmap='hot', xticklabels=xlab,
                     yticklabels=ylab, linecolor="Black", linewidths=.5)
    cbar = ax.collections[0].colorbar
    # here set the labelsize by 20
    cbar.ax.tick_params(labelsize=font_size_s)
    
    plt.savefig(args[2])

def readW(w_file):
    names = []  
    vals  = []  
    with open(w_file, 'r') as fh:
        for line in fh.readlines():
            line = line.strip()
            
            data = line.split("\t")
            (name, val) = (data[0], float(data[1]))
            names.append(name)
            vals.append(val)
    
    n_param = len(names)
    n_type  = len(stypes)
    if(n_param % n_type != 0):
        print("The number of parameters is not multiple of %d." % (n_type), file=sys.stderr)
        print("The image file is not created.", file=sys.stderr)
        exit()
    
    seqlen = int(n_param / n_type)

    w = np.full((seqlen, n_type), np.nan, dtype=float)
    
    for i in range(len(names)):
        (stype, pos) = names[i][1:].split('_')

        if not(stype in stypes):
            print("Unexpected parameter name %s" % names[i], file=sys.stderr)
            print("The image file is not created.", file=sys.stderr)
            exit()
            
        
        pos = int(pos)
        idx = stype2idx[stype]
        w[pos-1][idx] = vals[i]

    if(np.any(np.isnan(w))):
        print("Weight parameter file is incomplete.", file=sys.stderr)
        print("The image file is not created.", file=sys.stderr)
        exit()
    
    return w, seqlen

main()




