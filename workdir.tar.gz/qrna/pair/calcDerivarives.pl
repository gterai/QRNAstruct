#!/usr/bin/perl -w

use strict;
use FileHandle;

unless($#ARGV == 5){
    die "usage: $0 [id2exp.txt] [id2PF.txt] [id2CPF.txt] [id2BPP.txt] [w*.txt] [C]\n";
}

require "/home/terai/script/basic.pl";
my %id2exp      = readHash($ARGV[0]);
my %id2PF       = readHash($ARGV[1]);
my %id2CPF      = readHash($ARGV[2]);
my $id2BPP_href = readBPP($ARGV[3]);
my %W           = &readW($ARGV[4]);

my $C           = $ARGV[5];
#my %id2accC     = readHash($ARGV[6]);


# waの計算
my $Dwa = "NA"; # wb,wiを学習する
#my $Dwa = &calcDwa() + 2 * $C * $W{wa};
#my $Dwb = &calcDwb() + 2 * $C * $W{wb};
#my $Dwa = &calcDwa();

#my $Dwb = &calcDwb() + 2 * $C * exp(2 * $W{wb});
#my $Dwb = &calcDwb();
my $Dwb = "NA"; # wiを学習する
print "Dwa\t$Dwa\n";
print "Dwb\t$Dwb\n";

#for(my $i = 2; $i <= $#W; $i++){
for(my $i = 0; $i <= $W{L}; $i++){
    my $Dwi = &calcDwi($i) + 2 * $C * $W{wi}[$i];
    
    print "Dw$i\t$Dwi\n";
    
}

sub calcDwi{
    my $v;
    my $i = $_[0];
    
#    my $idx = $i - 2;
    foreach my $id (keys %id2CPF){
	my $t = $id2exp{$id};
	
#	my $lprob = log(exp($id2accC{$id}/((37+273.15) * 1.98717/1000)));
#	my $prob = exp($id2accC{$id}/((37+273.15) * 1.98717/1000));
	
#	my $y = $W[0] + $prob * exp($W[1]) * ($id2CPF{$id} - $id2PF{$id});
#	$v += 2*($y-$t) * $prob * exp($W[1]) * $id2BPP_href->{$id}[$idx];
#	my $y = $W{wa} + $prob * exp($W{wb}) * ($id2CPF{$id} - $id2PF{$id});
#	$v += 2*($y-$t) * $prob * exp($W{wb}) * $id2BPP_href->{$id}[$i];
	my $y = $W{wa} +  exp($W{wb}) * ($id2CPF{$id} - $id2PF{$id});
	$v += 2*($y-$t) * exp($W{wb}) * $id2BPP_href->{$id}[$i];
	
    }
    
    return $v;
   
}




sub readBPP{
    my %h;
    
    my $fh = new FileHandle($_[0]) || die;
    while(<$fh>){
        chomp;
        my ($id, @bpp) = split /\t/;;
        $h{$id} = \@bpp;

    }
    $fh->close();
    
    return \%h;
}

sub readPni{
    my %h;
    
    my $fh = new FileHandle($_[0]) || die;
    while(<$fh>){
        chomp;
        my @a = split /\t/;
        my ($id, $Pni, $Pfi) = ($a[0], $a[1], $a[2]);
        $h{$id} = $Pni;

    }
    $fh->close();

    return \%h;
}


sub readW{
    my %h;

    my $max_pos = -1;
    my $fh = new FileHandle($_[0]) || die "Can't open $_[0]:$!\n";
    while(<$fh>){
        chomp;

        if(/^(w[ab])/){
            my ($name, $val) = split /\t/;
            $h{$name} = $val;
        }
        elsif(/^w(\d+)/){
            my $pos = $1;
            my ($name, $val) = split /\t/;
            $h{wi}[$pos] = $val;
            $max_pos = $pos if($pos > $max_pos);
        }
        else{
            die "Unexpected line ($_)\n";
        }
    }
    $fh->close();

    $h{L} = $max_pos;

    return %h;
}
