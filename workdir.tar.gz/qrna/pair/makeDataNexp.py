# -*- coding: utf-8 -*-

import sys
sys.path.append("/qrna/common")
import basic
import numpy as np

args = sys.argv

if len(args) != 5:
    print("usage: {0} [act.txt] [id2prof.txt] [rrna len] [sd len]".format(__file__))
    exit(0)
    
xlen = int(args[3])
ylen = int(args[4])

def main():
    id2prof = readProf(args[2])
    
    id2act = basic.readHash(args[1])
    ids = id2prof.keys()
    id2Nact = normAct(id2act, ids)
    
    names_str = makeNames(xlen, ylen)
    print ("id\tact\t{0}".format(names_str))
    
    for id in id2prof:
        items = []
        items.append(id)
        items.append(str(id2Nact[id]))
        for i in range(len(id2prof[id])):
            #print(id2prof[id][i])
            items.append(id2prof[id][i])
        items_str = "\t".join(items)
        print(items_str)

def makeNames(xl, yl):
    names = []

    mod2stype = ['B', 'I', 'E']
    
    n_param = xl * yl + xl * 3 + yl * 3
    #print(n_param)
    #exit(0)
    for idx in range(n_param):
        if(idx < xl * yl):
            (i, j) = idx2ij(idx, xl, yl)
            i += 1 # 1-basedに変換
            j += 1 # 1-basedに変換
            names.append('P_' + str(i) + '_' + str(j))
        else:
            # type 0 = bulge
            # type 1 = internal
            # type 2 = external
            idx2  = idx - xl * yl # bppの分を引く
            stype  = mod2stype[idx2 % 3]
            
            seq_ij = 'y'
            pos  = int(idx2/3) + 1; # nucleotide position from 1...j and 1..i (1-based)
            if(pos > yl):  # seqX上の位置に変換する
                pos = pos - yl
                seq_ij = 'x'
            
            #print(seq_ij, pos)
            names.append(stype + '_' + seq_ij + '_' + str(pos))

    return '\t'.join(names)
    
def normAct(id2a, ids):
    values = []
    for id  in ids:
        values.append(float(id2a[id]))

    values.sort()
    #for v in values:
    #    print(v)
    max = values[-1]
    min = values[0]

    d = {}
    for id in ids:
        d[id] = (float(id2a[id]) - min)/(max - min)

    # ここでゼロノーマライズを行う。
    #print(d.values())
    mean = np.mean(list(d.values()))
    
    for id in ids:
        d[id] = d[id] - mean

    return d
        
def readProf(fname):
    d = {}
    with open(fname, 'r') as fh:
        for line in fh.readlines():
            line = line.strip()
            vals = line.split("\t")
            d[vals[0]] = vals[1:]
    
    return d


def idx2ij(ind, r, t):
    i = int(ind/t) # 0-based
    j = (ind % t)  # 0-based

    return (i, j)




main()
