# coding: utf-8

import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from PIL import Image, ImageFilter, ImageDraw, ImageFont

import sys
import math


args = sys.argv

if len(args) != 5:
    print("usage {0}: [w*.txt] [matP.png] [matX.png] [matY.png]".format(args[0]))
    exit()
    #print (len(args))

def main():
    (outfileP, outfileX, outfileY) = (args[2], args[3], args[4]) # 出力画像ファイル名

    (w, xlen, ylen) = readWpair(args[1])

    width = max(20, ylen)
    hight = int(width * (xlen/ylen))   # seqXは縦方向に表示
    
    figsizeP = (width, hight) 
    figsizeX = (width, 6)
    figsizeY = (width, 6)
    
    
    plt.figure(figsize=figsizeP)
    plt.subplots_adjust(left=0.15, right=1, bottom=0.15, top=0.9)
     
    vlab = [""] * xlen 
    for vi in range(xlen): # 縦軸(配列x)
        vlab[vi] = str(vi+1)
    
    hlab = [""] * ylen  # 横軸(配列y)
    for hi in range(ylen):
        hlab[hi] = str(hi+1)
    
    sns.set(font_scale=2.5)
    sns.heatmap(w['matP'], cmap='hot', vmax=w['max'], vmin=w['min'], linecolor="Black", linewidths=.5
                , xticklabels=hlab, yticklabels=vlab) 
    
    plt.xlabel("seqY (from 5' to 3')")
    plt.ylabel("seqX (from 3' to 5')")
    plt.yticks(rotation=0) 
    plt.savefig(outfileP)
    
    # matrixX
    stypes = ['B', 'I', 'E']
    sns.set(font_scale=2.5)
    plt.figure(figsize=figsizeX)
    plt.subplots_adjust(left=0.1, right=1, bottom=0.25, top=0.9)
    xlab = ['E', 'I', 'B']
    sns.heatmap(w['matX'].transpose(), cmap='hot', vmax=w['max'], vmin=w['min'], xticklabels=vlab,
                yticklabels=stypes, linecolor="Black", linewidths=.5) 
    plt.xlabel("seqX (from 3' to 5')")
    plt.savefig(outfileX)

    # matrixY
    stypes = ['B', 'I', 'E']
    sns.set(font_scale=2.5)
    plt.figure(figsize=figsizeY)
    plt.subplots_adjust(left=0.1, right=1, bottom=0.25, top=0.9)
    
    sns.heatmap(w['matY'].transpose(), cmap='hot', vmax=w['max'], vmin=w['min'], yticklabels=stypes,
                xticklabels=hlab, linecolor="Black", linewidths=.5,)
    plt.xlabel("seqY (from 5' to 3')")
    plt.savefig(outfileY)

    
def readWpair(w_file):
    
    (names,vals) = ([], [])
    with open(w_file, 'r') as fh:
        for line in fh.readlines():
            line = line.strip()
            
            data = line.split("\t")
            (name, val) = (data[0], float(data[1]))
            names.append(name)
            vals.append(val)
    
    # まず、Pからi,jの長さを求める。
    (xlen, ylen) = (0,0)
    for name in names:
        stype = name[1]
        if(stype == 'P'):
            (i,j) = name[3:].split('_')
            (i,j) = (int(i), int(j))
            if(i > xlen): xlen = i 
            if(j > ylen): ylen = j 

    # wに値を読み込む
    w = {}
    # 最初に行列を確保
    w['matP']  = np.full((xlen, ylen), np.nan, dtype=float)
    w['matX']  = np.full((xlen, 3),   np.nan, dtype=float)
    w['matY']  = np.full((ylen, 3),   np.nan, dtype=float)
    w['max']   = -1e100
    w['min']   = 1e100
    stype2ftype = {'B':0, 'I':1, 'E':2}
    
    for idx in range(len(names)):
        (name, val) = (names[idx], vals[idx])
        
        if w['max'] < val: w['max'] = val
        if w['min'] > val: w['min'] = val
        
        (stype, i, j) = (np.nan, np.nan, np.nan)
        stype = name[1]
        if(stype == 'P'):
            #print(name[3:])
            (i,j) = name[3:].split('_')
            (i,j) = (int(i), int(j))
            w['matP'][i-1][j-1] = val # 0-based
        elif(stype == 'B' or stype == 'I' or stype == 'E'):
            ftype  = stype2ftype[stype]
            (seq_xy, pos) = name[3:].split('_')
            #print(name, ftype, seq_xy, pos)
            
            mtype = ''
            if(seq_xy == 'x'):
                mtype = 'matX'
            elif(seq_xy == 'y'):
                mtype = 'matY'
            else:
                print("Unknonw sequnce type %d" % seq_xy, file=sys.stderr)
                exit(0)
                
            pos = int(pos)
            #print(mtype, pos, ftype, val)
            w[mtype][pos-1][ftype] = val
            
            # type 0 = bulge
            # type 1 = internal
            # type 2 = external
        else:
            print("Unexpected parameter name %s" % name, file=sys.stderr)
            print("The image file is not created.", file=sys.stderr)
            exit()

    if(np.any(np.isnan(w['matP'])) or np.any(np.isnan(w['matX'])) or np.any(np.isnan(w['matY']))):
        print("Weight parameter file is incomplete.", file=sys.stderr)
        print("The image file is not created.", file=sys.stderr)
        exit()
        
    return w, xlen, ylen


main()




