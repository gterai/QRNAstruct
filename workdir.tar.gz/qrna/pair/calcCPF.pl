#!/usr/bin/perl -w

use strict;
use FileHandle;
#use Statistics::RankCorrelation;
use FindBin;

my $ScriptDir = $FindBin::Bin;

unless($#ARGV == 4){
    die "usage: $0 [seq.mfa] [rrna.fa] [nCPU] [outfile(id2CPF.txt)] [out(id2BPP.txt)]\n";
}

require "$ScriptDir/../common/basic.pl";
require "$ScriptDir/../common/getEachSize.pl";


my %seq       = readSequence($ARGV[0]);
my $rrna_file = $ARGV[1];

my $seq_len   = &getLen(%seq);
my $rrna_len  = &getLen(readSequence($ARGV[1]));

#my $nCPU = 50;
#my $nCPU = 25;
my $nCPU = $ARGV[2];
if($nCPU > 50){
    die"uCPU ($nCPU) is too large.\n";
}

# CPU 1-3で計算する配列のIDを求める。
my $cID_href = &getCID();

# 一時ファイルが出来るディレクトリ
#my $tmp_dir = "/data1/terai/";
my $tmp_dir = "/tmp/optSingle/";
if(! -d $tmp_dir){
    `mkdir $tmp_dir`;
}
 
#my $tmp_dir = "/home/terai/Rfit/Cambray/script_learn_acc/tmp/";


# Forkして子ノードでPFを計算
my @oFiles;
#my @iFiles;
my %ForkReg;
for(my $b = 0; $b < $nCPU; $b++){
    
    my $file_out = $tmp_dir . "$b" . "out$$" . time; # ここでの$$は親プロセスのID
    push(@oFiles, $file_out);
    
  FORK:{
      my $pid;
      if($pid = fork){
	  # parent process
	  $ForkReg{$pid} = 1;
      }
      elsif(defined $pid){
	  # child process
	  
	  my $tmp_file_in  = $tmp_dir . "in$$" . time;  # ここでの$$は子プロセスのID
#	  print "$tmp_file_in\n";
	  
	  my @ids = @{$cID_href->[$b]};
	  &calcPF_in_child(\@ids, $tmp_file_in, $file_out);
	  
#	  push(@iFiles, $tmp_file_in);
	  
	  exit(0); ######### IMPORTANT !!! #################
	  
      }
      elsif($! =~ /No more process/){
	  sleep 5;
	  redo FORK;
      }
      else{
	  die "Can't fork: $!\n";
      }
      
    }
    
}



while(1){
    my @num_proc = keys %ForkReg;
    last if($#num_proc == -1);

    my $end_proc_id = wait;
    
    print STDERR "child process $end_proc_id finished.\n";
    
    unless(defined $ForkReg{$end_proc_id}){
	die "Unknown process id was returned ($end_proc_id).\n";
    }
    else{
	delete $ForkReg{$end_proc_id};
    }
}


my (%pf, %bpp, %prof);
foreach my $ofile (@oFiles){
    open(OF, "$ofile") || die;
    my $id;
    while(<OF>){
	chomp;
	if(/^Partition/){
	    /^Partition function of (\S+) \= (\S+)$/ or die "Can't parse PF from $_\n";
	    my ($id_tmp, $pf) = ($1, $2);
	    $id = $id_tmp;
	    $pf{$id} = $pf;
	}
	elsif(/^\d/){
	    my ($i, $j, $p) = split / /;
	    $bpp{$id}[$i][$j] = $p;
	}
	elsif(/^[ij]\d+/){
	    my ($pos, @prob) = split / /;
            $pos =~ /^([ij])(\d+)$/ or die "Can't parse position from $_\n";
	    my ($iorj, $cord) = ($1, $2);
	    #print "$iorj\t$cord\n";
	    @{$prof{$id}{"seq$iorj"}[$cord]} = @prob[0..$#prob-1]; # the last colmn contains sum of prob.
	    
	}
	elsif(/^\/\//){
	    # skip
	}
	else{
	    die "Unexpected line ($_)\n";
	}
    }
    close(OF);
    
}

# make output files
open(OPF, ">$ARGV[3]") || die;
foreach my $id (sort keys %pf){
    print OPF "$id\t$pf{$id}\n";
}
close(OPF);
open(OBP, ">$ARGV[4]") || die;
foreach my $id (sort keys %pf){
    print OBP "$id";
    # output base pair probability
    for(my $i = 1; $i <= $rrna_len; $i++){
	for(my $j = 1; $j <= $seq_len; $j++){
	    my $p = 0;
	    $p = $bpp{$id}[$i][$j] if(defined $bpp{$id}[$i] && defined $bpp{$id}[$i][$j]);
	    print OBP "\t$p";
	}
    }
    # output profile
    for(my $j = 1; $j <= $seq_len; $j++){
	print OBP "\t$prof{$id}{seqj}[$j][1]\t$prof{$id}{seqj}[$j][2]\t$prof{$id}{seqj}[$j][3]"; # bulge->internal->external
    }
    for(my $i = 1; $i <= $rrna_len; $i++){
	print OBP "\t$prof{$id}{seqi}[$i][1]\t$prof{$id}{seqi}[$i][2]\t$prof{$id}{seqi}[$i][3]";
    }

    print OBP "\n";
    
}
close(OBP);

### delete all temporary files
foreach my $ofile (@oFiles){
    `rm $ofile`;
}
### delete all temporary files
#foreach my $ifile (@iFiles){
#    `rm $ifile`;
#}

sub calcPF_in_child{
    my (%pf, %bpp);
    my @ids     = @{$_[0]};
    my $in_file = $_[1];
    my $out_file = $_[2];
    
    open(OUT, ">$in_file") || die "Can't open $in_file:$!\n";
    foreach my $id (@ids){
	print OUT ">$id\n";
	print OUT "$seq{$id}\n";
    }
    close(OUT);
    
    my $command_1 = "perl $ScriptDir/CapB5.pl $in_file $rrna_file > $out_file";
    #print STDERR "$command_1\n";
    `$command_1`;
    `rm $in_file`;
}

sub getCID{
    my @a; # an array to be returned

    my @ids = keys %seq;
    my @bin = getEachSize(scalar @ids, $nCPU);

    for(my $b = 0; $b <= $#bin; $b++){

	for(my $j = 0; $j < $bin[$b]; $j++){
	    my $id = pop(@ids);
	    push(@{$a[$b]}, $id);
#	    print "$id\t$b\n";
	}


    }
    
    return \@a;
}

sub getLen{
    my $len;

    my %h = @_;
    foreach my $id (keys %h){
        if(!defined $len){
            $len = length($h{$id});
        }
        else{
            my $len2 = length($h{$id});
            if($len != $len2){
                die "Different rbs sequence length ($len:$len2)\n";
            }
        }
    }

    return $len;
}

