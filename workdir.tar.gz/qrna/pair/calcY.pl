#!/usr/bin/perl -w

use strict;
use FileHandle;

unless($#ARGV == 2){
    die "usage: $0 [id2PF.txt] [id2CPF.*.txt] [w*.txt]\n";
}

require "/home/terai/script/basic.pl";

my %id2PF       = readHash($ARGV[0]);
my %id2CPF      = readHash($ARGV[1]);
my %W           = &readW($ARGV[2]);

foreach my $id (keys %id2CPF){
#    my $accC = $id2accC{$id};
#    my $lprob = log(exp($id2accC{$id}/((37+273.15) * 1.98717/1000)));
#    my $prob = exp($id2accC{$id}/((37+273.15) * 1.98717/1000));
    
#    my $y = $Wab{wa} + $prob * exp($Wab{wb}) * ($id2CPF{$id} - $id2PF{$id});
#    my $y = $W{wa} + $prob * $W{wb} * ($id2CPF{$id} - $id2PF{$id});
#    my $y = $W{wa} + $prob * exp($W{wb}) * ($id2CPF{$id} - $id2PF{$id});
    
#    my $f = $W{wa} + exp($W{wb}) * ($id2CPF{$id} - $id2PF{$id});
    #    my $y = $prob * $f;
    
    my $y = $W{wa} + exp($W{wb}) * ($id2CPF{$id} - $id2PF{$id});
    print "$id\t$y\n";
}

sub readW{
    my %h;

    my $max_pos = -1;
    my $fh = new FileHandle($_[0]) || die "Can't open $_[0]:$!\n";
    while(<$fh>){
        chomp;

        if(/^(w[ab])/){
            my ($name, $val) = split /\t/;
            $h{$name} = $val;
        }
        elsif(/^w(\d+)/){
            my $pos = $1;
            my ($name, $val) = split /\t/;
            $h{wi}[$pos] = $val;
            $max_pos = $pos if($pos > $max_pos);
        }
        else{
            die "Unexpected line ($_)\n";
        }
    }
    $fh->close();
    
    $h{L} = $max_pos;
    
    return %h;
    
}

