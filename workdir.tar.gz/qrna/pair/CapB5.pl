#!/usr/bin/perl -w

use strict;
use FileHandle;
use Getopt::Long;
use FindBin;

my $ScriptDir = $FindBin::Bin;

unless($#ARGV >= 1){
    die "usage: $0 [train.mfa] [rnaX.fasta] --ME --BPF\n";
}
my @Test;
#require "/home/terai/script/basic.pl";

### getSequence and their length
my @Rseq = &to1basedArray(scalar(reverse(&readOneSeq($ARGV[1]))));
my $R = $#Rseq;
my %Seq = &readSequence($ARGV[0]);
my $T = &getLen(%Seq);
my @Tseq;

my ($ME, $BPF);
GetOptions('ME'=>\$ME, 'BPF'=>\$BPF);

##### read additional patameters #####
my %W = &makeZeroW($R, $T);
my @SWJbul = &calcWJspan(\%W, 0);
my @SWJint = &calcWJspan(\%W, 1);
my @SWJext = &calcWJspan(\%W, 2);
my @SWIbul = &calcWIspan(\%W, 0);
my @SWIint = &calcWIspan(\%W, 1);
my @SWIext = &calcWIspan(\%W, 2);

####################################### parameter settings
my $D_MAX_HAIRPIN_LENGTH = 30;
my $C_MAX_SINGLE_LENGTH  = 30;
my %Param;
#&readCONTRAfoldParam("./contrafold.params.complementary", \%Param);
&readCONTRAfoldParam("$ScriptDir/contrafold.params.complementary", \%Param);
my (@sHairpinLength);    # ヘアピンの長さに対するスコア
my (%sHelixClosing);     # ヘリックスを閉じるときのスコア
my (%sTerminalMismatch); # ループの端っこにかかるミスマッチスコア
my (@sSingle);           # バルジとインターナルループの塩基にかかるスコア
my (%sBasePair);         # ここに塩基対ごとのパラメータを格納する（学習用のパラメータも入れる）
my (%sStacking);         # スタッキング
my (%sBulge_1);          # 長さ１のバルジ
my (%sInternal_11);      # 長さ１のインターナルループ
my $sExtPair;            # 外側塩基対
my $sExtUnpair;          # 外側塩基
my %sDangleL;            # 左側ダングル
my %sDangleR;            # 右側ダングル
&setParam();

my %BP = &setBP();
my $Turn = 0;
####################################### 

foreach my $id (sort keys %Seq){
    
    @Tseq = &to1basedArray($Seq{$id});
    
#   my @TB; # トレースバック用の行列
    
    my $T = $#Tseq;
    
    my (@F1, @F2, @V);
    
    # 初期化
    $F1[0][0] = 1;   # e(0)
    $F2[0][0] = 0;   # e(Inf)
    $V[0][0]  = 0;   # e(Inf)
    for(my $i = 1; $i <= $R; $i++){
	#$F1[$i][0] = exp($sExtUnpair * $i);
	$F1[$i][0] = exp($sExtUnpair * $i + $SWIext[1][$i]);
	$F2[$i][0] = 0;
	$V[$i][0]  = 0;
    }
    for(my $j = 1; $j <= $T; $j++){
	$F1[0][$j] = exp($sExtUnpair * $j + $SWJext[1][$j]);
	$F2[0][$j] = 0;
	$V[0][$j]  = 0;
    }
    
    # Forward
    for(my $i = 1; $i <= $R; $i++){
	for(my $j = 1; $j <= $T; $j++){
	    
	    if($BP{$Rseq[$i]}{$Tseq[$j]}){  # i and j can form pair
		
		# the left most base pair
		my $c = exp(&ScoreBasePair($i,$j)
			    + $sExtPair + $sHelixClosing{"$Tseq[$j]$Rseq[$i]"}); # note that helix closing is reversed
		if($i > 1){
		    $c *= exp($sDangleR{"$Tseq[$j]$Rseq[$i]$Rseq[$i-1]"}); 
		}
		if($j > 1){
		    $c *= exp($sDangleL{"$Tseq[$j]$Rseq[$i]$Tseq[$j-1]"});
		}
		$V[$i][$j] += $c * $F1[$i-1][$j-1];
		
		# intloop
#		for(my $h = 1; $h <= $i-1; $h++){
		for(my $h = $i-1; $h >= 1; $h--){
		    my $lenR = $i - $h - 1; 
		    last if($lenR > $C_MAX_SINGLE_LENGTH);
#		    print "TEST\t$h,\$l,$i,$j\n";
		    
#		    for(my $l = 1; $l <= $j-1; $l++){
		    for(my $l = $j-1; $l >= 1; $l--){
			my $lenT= $j - $l - 1;
#			print "TEST\t$h,$l,$i,$j\t$lenT\t$lenR\n";
			last if($lenT > $C_MAX_SINGLE_LENGTH); 
			last if($lenR + $lenT > $C_MAX_SINGLE_LENGTH);
			if($BP{$Rseq[$h]}{$Tseq[$l]}){
#			    print "FW\t$h,$l,$i,$j\n";
			    
			    my $c2 = 0;
			    if($lenR + $lenT == 0){ # stacking
				$c2 = exp(&ScoreBasePair($i,$j) + $sStacking{"$Tseq[$l]$Rseq[$h]$Tseq[$j]$Rseq[$i]"}) * $V[$h][$l];
#				$c2 = exp($sBasePair{"$Rseq[$i]$Tseq[$j]"} + $sStacking{"$Tseq[$l]$Rseq[$h]$Tseq[$j]$Rseq[$i]"}) * $V[$h][$l];
#				$c2 = exp($sBasePair{"$Rseq[$i]$Tseq[$j]"}) * $V[$h][$l];
			    }
			    else{
				# h,l周りのスコア（ターミナル塩基対とミスマッチ）
				my $aroundHL = exp($sTerminalMismatch{"$Tseq[$l]$Rseq[$h]$Tseq[$l+1]$Rseq[$h+1]"} +
				                   $sHelixClosing{"$Tseq[$l]$Rseq[$h]"}); 
#				my $aroundHL = 1;
				my $between  = exp($sSingle[$lenT][$lenR] + &ScoreSmallLoops($j,$i,$l,$h)); 
#				my $between  = 1; 
                                # i,j周りのスコア（ターミナル塩基対とミスマッチ）
				my $aroundIJ = exp($sTerminalMismatch{"$Rseq[$i]$Tseq[$j]$Rseq[$i-1]$Tseq[$j-1]"} +
				                   $sHelixClosing{"$Rseq[$i]$Tseq[$j]"} + &ScoreBasePair($i, $j)); 
#				                   $sHelixClosing{"$Rseq[$i]$Tseq[$j]"} + $sBasePair{"$Rseq[$i]$Tseq[$j]"}); 
#				my $aroundIJ = 1;
#				print "FW\t$h,$l,$i,$j\n";
				$c2 = $aroundIJ * $between * $aroundHL * $V[$h][$l];
#				print "$i\t$j\t$h\t$l\t$c2\n";
				
				# Internal and budge weight is added here.
				if($lenR > 0 && $lenT > 0){ # internal loop
				    $c2 *= exp($SWJint[$l+1][$lenT]);
				    $c2 *= exp($SWIint[$h+1][$lenR]);
				}
				elsif($lenR == 0 && $lenT > 0){ # bulge loop in seq.j
				    $c2 *= exp($SWJbul[$l+1][$lenT]);
				}
				elsif($lenR > 0 && $lenT >= 0){ # bulge loop in seq.i
				    $c2 *= exp($SWIbul[$h+1][$lenR]);
				}
			    }
			    
			    $V[$i][$j]  += $c2;

			}
		    }
		}
	    }
	    else{
		$V[$i][$j] = 0;
	    }
	    
	    # filling F1 matrix
	    $F1[$i][$j] = 0;
#	    $F1[$i][$j] += $F1[$i-1][$j] * exp($sExtUnpair);
	    $F1[$i][$j] += $F1[$i-1][$j] * exp($sExtUnpair + $SWIext[$i][1]); 
	    
	    # filling F2 matrix
	    $F2[$i][$j] = 0;
#	    $F2[$i][$j] += $F2[$i-1][$j] * exp($sExtUnpair);
	    $F2[$i][$j] += $F2[$i-1][$j] * exp($sExtUnpair + $SWIext[$i][1]);
	    if($i == $R){
		$F2[$i][$j] += $F2[$i][$j-1] * exp($sExtUnpair + $SWJext[$j][1]); 
	    }
	    
	    # right most base pair
	    my $v = $V[$i][$j] * exp($sExtPair + $sHelixClosing{"$Rseq[$i]$Tseq[$j]"});
	    if($i < $R){
		$v *= exp($sDangleL{"$Rseq[$i]$Tseq[$j]$Rseq[$i+1]"}); 
	    }
	    if($j < $T){
		$v *= exp($sDangleR{"$Rseq[$i]$Tseq[$j]$Tseq[$j+1]"});
	    }
#	    my $tPF = $v * exp(($R-$i + $T-$j) * $sExtUnpair);
#	    print "$i\t$j\t$tPF\n" if($v != 0);
	    
	    $F2[$i][$j] += $v;
#	    $F2[$i][$j] += $V[$i][$j];
	    
	}
    }

    # Backward
    my (@B1, @B2, @BV);
    $B2[$R][$T] = 1;   # e(0) (Score = 0)
    $B1[$R][$T] = 0;   
    $BV[$R][$T] = 0; 
    if($BP{$Rseq[$R]}{$Tseq[$T]}){  # $R and $T can form pair
#	$BV[$R][$T] = $B2[$R][$T];
	$BV[$R][$T] = exp($sExtPair + $sHelixClosing{"$Rseq[$R]$Tseq[$T]"}) * $B2[$R][$T]; # right most base pair
    }
    for(my $i = $R-1; $i >= 0; $i--){
	$B2[$i][$T] = exp($sExtUnpair + $SWIext[$i+1][1]) * $B2[$i+1][$T];
	$B1[$i][$T] = 0;
	$BV[$i][$T] = 0;
	if($BP{$Rseq[$i]}{$Tseq[$T]}){  # $i and $T 
#	    $BV[$i][$T] = $B2[$i][$T];
	    $BV[$i][$T] = $B2[$i][$T] * 
		exp($sExtPair + $sHelixClosing{"$Rseq[$i]$Tseq[$T]"}) *
		exp($sDangleL{"$Rseq[$i]$Tseq[$T]$Rseq[$i+1]"}); # right most base pair
	}
    }
    for(my $j = $T-1; $j >= 0; $j--){
	$B2[$R][$j] = exp($sExtUnpair + $SWJext[$j+1][1]) * $B2[$R][$j+1];
	$B1[$R][$j] = 0;
	$BV[$R][$j] = 0;
	if($BP{$Rseq[$R]}{$Tseq[$j]}){  # $R and $j
#	    $BV[$R][$j] = $B2[$R][$j];
	    $BV[$R][$j] = $B2[$R][$j] * 
		exp($sExtPair + $sHelixClosing{"$Rseq[$R]$Tseq[$j]"}) * 
		exp($sDangleR{"$Rseq[$R]$Tseq[$j]$Tseq[$j+1]"}); # right most base pair
	}
    }
    
    # run dp
    for(my $i = $R-1; $i >= 0; $i--){
	for(my $j = $T-1; $j >= 0; $j--){
	    #print "$i\t$j\n";
	    # filling B2 matrix (This must be done before filling BV[i][j])
	    $B2[$i][$j] = $B2[$i+1][$j] * exp($sExtUnpair + $SWIext[$i+1][1]);
	    
	    if($BP{$Rseq[$i]}{$Tseq[$j]}){  # i and j can form pair
		
		# the right most base pair
		my $r = exp($sExtPair + $sHelixClosing{"$Rseq[$i]$Tseq[$j]"});
		$r *= exp($sDangleL{"$Rseq[$i]$Tseq[$j]$Rseq[$i+1]"}); 
		$r *= exp($sDangleR{"$Rseq[$i]$Tseq[$j]$Tseq[$j+1]"});
		
		$BV[$i][$j] = $B2[$i][$j] * $r;
#		$BV[$i][$j] = $B2[$i][$j] * 1;
#		for(my $p = $R; $p >= $i+1; $p--){
		for(my $p = $i+1; $p <= $R; $p++){
		    my $lenR = $p - $i - 1; 
		    last if($lenR > $C_MAX_SINGLE_LENGTH);
#		    for(my $q = $T; $q >= $j+1; $q--){
		    for(my $q = $j+1; $q <= $T; $q++){
			
			my $lenT= $q - $j - 1;
			last if($lenT > $C_MAX_SINGLE_LENGTH); 
			last if($lenR + $lenT > $C_MAX_SINGLE_LENGTH);
			if($BP{$Rseq[$p]}{$Tseq[$q]}){
#			    print "BK\t$i,$j,$p,$q\n";
			    
			    my $c2 = 0;
			    if($lenR + $lenT == 0){ # stacking
				# Do not include sBasePair[i][j] !
				$c2 = exp($sStacking{"$Tseq[$j]$Rseq[$i]$Tseq[$q]$Rseq[$p]"} + &ScoreBasePair($p,$q)) * $BV[$p][$q];
#				$c2 = exp($sStacking{"$Tseq[$j]$Rseq[$i]$Tseq[$q]$Rseq[$p]"} + $sBasePair{"$Rseq[$p]$Tseq[$q]"}) * $BV[$p][$q];
#				$c2 = exp($sBasePair{"$Rseq[$p]$Tseq[$q]"}) * $BV[$p][$q];
			    }
			    else{
				# p,q周りのスコア（ターミナル塩基対とミスマッチ）
#				my $aroundPQ = 1;
				my $aroundPQ = exp($sTerminalMismatch{"$Rseq[$p]$Tseq[$q]$Rseq[$p-1]$Tseq[$q-1]"} +
##				                   $sHelixClosing{"$Rseq[$p]$Tseq[$q]"} + $sBasePair{"$Rseq[$p]$Tseq[$q]"});
				                   $sHelixClosing{"$Rseq[$p]$Tseq[$q]"} + &ScoreBasePair($p,$q));
				my $between  = exp($sSingle[$lenT][$lenR] + &ScoreSmallLoops($q,$p,$j,$i)); # must be q > j && p > i
#				my $between  = 1;
				# i,j周りのスコア（ターミナル塩基対とミスマッチ）
				my $aroundIJ = exp($sTerminalMismatch{"$Tseq[$j]$Rseq[$i]$Tseq[$j+1]$Rseq[$i+1]"} +
				                   $sHelixClosing{"$Tseq[$j]$Rseq[$i]"}); 
#				my $aroundIJ = 1;
#                                print "BK\t$i,$j,$p,$q\n";
				$c2 = $aroundPQ * $between * $aroundIJ * $BV[$p][$q];
#				print "$i\t$j\t$p\t$q\t$c2\t$V[$p][$q]\n";
				
				# Internal and budge weight is added here.
				if($lenR > 0 && $lenT > 0){ # internal loop
				    $c2 *= exp($SWJint[$j+1][$lenT]);
				    $c2 *= exp($SWIint[$i+1][$lenR]);
				}
				elsif($lenR == 0 && $lenT > 0){ # bulge loop in seq.j
				    $c2 *= exp($SWJbul[$j+1][$lenT]);
				}
				elsif($lenR > 0 && $lenT == 0){ # bulge loop in seq.i
				    $c2 *= exp($SWIbul[$i+1][$lenR]);
				}
			    }
			    
			    $BV[$i][$j]  += $c2;

			}
		    }
		}
	    }
	    else{
		$BV[$i][$j] = 0;
	    }
	    
	    # filling B1 matrix
#	    $B1[$i][$j] += $B1[$i+1][$j] * exp($sExtUnpair);
	    $B1[$i][$j] += $B1[$i+1][$j] * exp($sExtUnpair + $SWIext[$i+1][1]);
	    if($i == 0){
		$B1[$i][$j] += $B1[$i][$j+1] * exp($sExtUnpair + $SWJext[$j+1][1]);
		#print "$i,$j: $B1[$i][$j]: $B1[$i][$j+1]\n";
	    }
	    
	    # the left most base pair
	    if($BP{$Rseq[$i+1]}{$Tseq[$j+1]}){
		my $l = exp(&ScoreBasePair($i+1, $j+1) + $sExtPair
		    + $sHelixClosing{"$Tseq[$j+1]$Rseq[$i+1]"}); 
		$l *= exp($sDangleL{"$Tseq[$j+1]$Rseq[$i+1]$Tseq[$j]"}) if($j > 0);
		$l *= exp($sDangleR{"$Tseq[$j+1]$Rseq[$i+1]$Rseq[$i]"}) if($i > 0);
		$B1[$i][$j] += $l * $BV[$i+1][$j+1];
	    }
	}
    }

#    &dispMat(\@F1, "F1");
#    &dispMat(\@F2, "F2");
#    &dispMat(\@V, "V");
#    &dispMat(\@B1, "B1");
#    &dispMat(\@B2, "B2");
#    &dispMat(\@BV, "BV");
    
    my $PF  = $F1[$R][$T] + $F2[$R][$T];
    my $PFb = $B1[0][0] + $B2[0][0];

    if($PFb == 0){
	print "Partition function of $id = too small\n";
	next;
    }
    
    #print "$PF/$PFb.\n";
    if(abs($PF/$PFb) <= 0.99999 || abs($PF/$PFb) >= 1.00001){
	die "PF of $id obtained from forward ($PF) and backward ($PFb) differs.\n";
    }
    my $lpf = log($PF);
    print "Partition function of $id = $lpf\n";
    
    # calculating base pair probability
    my @bpp;
    my (@bpp_c, @bpp_nc);
    for(my $i = 1; $i <= $R; $i++){
	for(my $j = 1; $j <= $T; $j++){
	    my $pair = "$Rseq[$i]$Tseq[$j]";
	    if($BP{$Rseq[$i]}{$Tseq[$j]}){
		my $p;
		if(defined $BPF){
		    $p = ($V[$i][$j] * $BV[$i][$j]);
		}
		else{
		    $p = ($V[$i][$j] * $BV[$i][$j])/$PF;
		}
		#print "$i\t$j\t$bpp\n";
		#$bpp[$i][$j] = $p;
		if($pair eq "GU" || $pair eq "UG"){
		    $bpp_nc[$i][$j] = $p;
		    $bpp_c[$i][$j] = 0;
		}
		else{
		    $bpp_nc[$i][$j] = 0;
		    $bpp_c[$i][$j] = $p;
		}
	    }
	    else{
		#$bpp[$i][$j] = 0;
		$bpp_c[$i][$j] = 0;
		$bpp_nc[$i][$j] = 0;
	    }
	    $bpp[$i][$j] = $bpp_c[$i][$j] + $bpp_nc[$i][$j];
	    print "$i $j $bpp[$i][$j]\n" if($bpp[$i][$j] != 0);
	}
    }
    
    # calculating double strand probability for sequence (j)
    my (@Dp_j, @Dp_j_c, @Dp_j_nc);
    for(my $j = 1; $j <= $T; $j++){
	$Dp_j[$j] = 0;
	for(my $i = 1; $i <= $R; $i++){
	    $Dp_j[$j] += $bpp[$i][$j];
	    $Dp_j_c[$j] += $bpp_c[$i][$j];
	    $Dp_j_nc[$j] += $bpp_nc[$i][$j];
	}
    }
    # calculating double strand probability for sequence (i)
    my (@Dp_i, @Dp_i_c, @Dp_i_nc);
    for(my $i = 1; $i <= $R; $i++){
	$Dp_i[$i] = 0;
	for(my $j = 1; $j <= $T; $j++){
	    $Dp_i[$i] += $bpp[$i][$j];
	    $Dp_i_c[$i] += $bpp_c[$i][$j];
	    $Dp_i_nc[$i] += $bpp_nc[$i][$j];
	}
    }
    
#    my @lp_j = &calcPj(\@V, \@BV, $PF);    # calculating bulge and internal loop probability (RBS:Tseq)
    my ($Bp_j_aref, $Ip_j_aref)  = &calcPj_fast(\@V, \@BV, $PF);    # calculating bulge and internal loop probability (RBS:Tseq)
    my ($Bp_i_aref, $Ip_i_aref)  = &calcPi_fast(\@V, \@BV, $PF);    # calculating bulge and internal loop probability (rrna:Rseq)
#    my @Ep_j = &calcEPj(\@V, \@BV, $PF);    # calculating external probability for seq.j
#    @Test = @Ep_j;
    my ($Ep_i_aref, $Ep_j_aref) = &calcEP(\@V, \@BV, $PF);    # calculating external probability for seq.i
#    my ($Bp_j_aref, $Ip_j_aref) = &calcBpIp_j(\@lp_j);
    my $Np_j = exp(($R+$T)*$sExtUnpair+$SWJext[1][$T]+$SWIext[1][$R])/$PF;
    my $Np_i = $Np_j;
    
    my @Ep_j = @{$Ep_j_aref}; # External prob. for seq.j
    my @Ep_i = @{$Ep_i_aref}; # External prob. for seq.i
    # print profile for seq.j
    for(my $j = 1; $j <= $T; $j++){
	#my $sum = $Ep_j[$j]+$Dp_j[$j]+$Bp_j_aref->[$j]+$Ip_j_aref->[$j]+$Np_j;
	my $sum = $Ep_j[$j]+$Dp_j_c[$j]+$Dp_j_nc[$j]+$Bp_j_aref->[$j]+$Ip_j_aref->[$j]+$Np_j;
	
#	printf("j%d %.7f %.7f %.7f %.7f %.7f\n",
	printf("j%d %.7f %.7f %.7f %.7f %.7f %.7f\n",
	       $j, $Dp_j_c[$j], $Bp_j_aref->[$j], $Ip_j_aref->[$j], $Ep_j[$j] + $Np_j, $Dp_j_nc[$j], $sum); # DspCanonical, bulge, internal, external, DspNonCanonical
	if($sum > 1.00001 || $sum < 0.99999){
	    die "The sum of probabilities in j=$j is not 1 ($sum)\n";
	}
    }
    
    # print profile for seq.i
    for(my $i = 1; $i <= $R; $i++){
#	my $sum = $Ep_i[$i]+$Dp_i[$i]+$Bp_i_aref->[$i]+$Ip_i_aref->[$i]+$Np_i;
	my $sum = $Ep_i[$i]+$Dp_i_c[$i]+$Dp_i_nc[$i]+$Bp_i_aref->[$i]+$Ip_i_aref->[$i]+$Np_i;
	printf("i%d %.7f %.7f %.7f %.7f %.7f %.7f\n",
	       $i, $Dp_i_c[$i], $Bp_i_aref->[$i], $Ip_i_aref->[$i], $Ep_i[$i] + $Np_i, $Dp_i_nc[$i], $sum); 
	
	if($sum > 1.00001 || $sum < 0.99999){
	    die "The sum of probabilities in i=$i is not 1 ($sum)\n";
	}
    }
    
    print "//\n";
    
}



sub calcEP{
    my @v  = @{$_[0]};
    my @bv = @{$_[1]};
    my $pf = $_[2];
    
    my (@BolI, @BolJ); # sum of "external" boltzman factors for each base
    for(my $k = 1; $k <= $R; $k++){
	for(my $m = 1; $m <= $T; $m++){
	    if($BP{$Rseq[$k]}{$Tseq[$m]}){
		
		# k-m塩基対が対象位置よりも左(上流）にある場合
		# consider the right most base pair
		my $o1 = exp($sExtPair + $sHelixClosing{"$Rseq[$k]$Tseq[$m]"});
		if($k < $R){
		    $o1 *= exp($sDangleL{"$Rseq[$k]$Tseq[$m]$Rseq[$k+1]"}); 
		}
		if($m < $T){
		    $o1 *= exp($sDangleR{"$Rseq[$k]$Tseq[$m]$Tseq[$m+1]"});
		}
#		$or *= exp((($R - $k) + ($T - $m) ) * $sExtUnpair + $SWJext[$m+1][$T-$m]);
		$o1 *= exp((($R - $k) + ($T - $m)) * $sExtUnpair);
		$o1 *= exp($SWJext[$m+1][$T-$m]) if($m < $T);
		$o1 *= exp($SWIext[$k+1][$R-$k]) if($k < $R);
		
		# k-m塩基対が対象位置よりも右(下流）にある場合
		# consider the left most base pair
		my $o2 = exp(&ScoreBasePair($k, $m) + $sExtPair
			    + $sHelixClosing{"$Tseq[$m]$Rseq[$k]"});  # not that it includes ScoreBasePair
		$o2 *= exp($sDangleL{"$Tseq[$m]$Rseq[$k]$Tseq[$m-1]"}) if($m > 1);
		$o2 *= exp($sDangleR{"$Tseq[$m]$Rseq[$k]$Rseq[$k-1]"}) if($k > 1);
		
		$o2 *= exp(($k - 1 + $m - 1) * $sExtUnpair);
		$o2 *= exp($SWJext[1][$m-1]) if($m > 1);
		$o2 *= exp($SWIext[1][$k-1]) if($k > 1);
		
		# jについてのボルツマンファクターの計算
		for(my $j = $m+1; $j <= $T; $j++){ # case 1
		    #print "L:$k-$m\n" if($j == 2);
		    $BolJ[$j] += $v[$k][$m] * $o1; 
		}
		for(my $j = 1; $j < $m; $j++){ # case 2
		    $BolJ[$j] += $bv[$k][$m] * $o2;
		    #my $tmp = $bv[$k][$m] * $o2;
		    #print "L:$k-$m\t$tmp\n" if($j == 2);
		}
		
		# iについてのボルツマンファクターの計算
		for(my $i = $k+1; $i <= $R; $i++){ # case 1
		    $BolI[$i] += $v[$k][$m] * $o1; 
		}
		for(my $i = 1; $i < $k; $i++){ # case 2
		    $BolI[$i] += $bv[$k][$m] * $o2;
		}
		
	    }
	    
	}
    }

    my (@pi, @pj);
    for(my $i = 1; $i <= $R; $i++){
	$pi[$i] = $BolI[$i]/$pf;
    }
    for(my $j = 1; $j <= $T; $j++){
	$pj[$j] = $BolJ[$j]/$pf;
	#print "$Test[$j] = $pj[$j]\n";
    }
    #exit(0);
    return (\@pi, \@pj);
}




sub calcEPj{
    my @v  = @{$_[0]};
    my @bv = @{$_[1]};
    my $pf = $_[2];
    
    my @p;
    for(my $j = 1; $j <= $T; $j++){ 
	$p[$j] = 0;
    }
    
    my @Bol;
    for(my $j = 1; $j <= $T; $j++){
	my $bol = 0;
	for(my $k = 1; $k <= $R; $k++){
	    for(my $m = 1; $m <= $T; $m++){
		
		if($BP{$Rseq[$k]}{$Tseq[$m]}){
		    if($m < $j){    # case 1
			print "R2:$k-$m\n" if($j == 2);
			
			# consider the right most base pair
			my $o = exp($sExtPair + $sHelixClosing{"$Rseq[$k]$Tseq[$m]"});
			if($k < $R){
			    $o *= exp($sDangleL{"$Rseq[$k]$Tseq[$m]$Rseq[$k+1]"}); 
			}
			if($m < $T){
			    $o *= exp($sDangleR{"$Rseq[$k]$Tseq[$m]$Tseq[$m+1]"});
			}
			$o *= exp((($R - $k) + ($T - $m) ) * $sExtUnpair + $SWJext[$m+1][$T-$m]);
			$o *= exp($SWIext[$k+1][$R-$k]) if($k < $R);
			$bol += $v[$k][$m] * $o;
			
		    }
		    elsif($j < $m){ # case 2
			print "L2:$k-$m\n" if($j == 2);
			# consider the left most base pair
			my $o = exp(&ScoreBasePair($k, $m) + $sExtPair
				    + $sHelixClosing{"$Tseq[$m]$Rseq[$k]"});  # not that it includes ScoreBasePair
			$o *= exp($sDangleL{"$Tseq[$m]$Rseq[$k]$Tseq[$m-1]"}) if($m > 1);
			$o *= exp($sDangleR{"$Tseq[$m]$Rseq[$k]$Rseq[$k-1]"}) if($k > 1);
			
			$o *= exp(($k - 1 + $m - 1) * $sExtUnpair);
			$o *= exp($SWJext[1][$m-1]) if($m > 1);
			$o *= exp($SWIext[1][$k-1]) if($k > 1);
			
			#my $tmp = $bv[$k][$m] * $o;
			#print "L2:$k-$m\t$tmp\n" if($j == 1);
			
			$bol += $bv[$k][$m] * $o;
			
		    }
		}
	    }
	    
	}
	my $prob = $bol/$pf;
	$p[$j] = $prob;
	#print "$j $prob\n";
    }
    #exit(0);
    return @p;
}


sub calcBpIp_j{
    my $p_aref = $_[0];
    my (@Bp, @Ip); # Bp: bulge probability, Ip: internal loop probability
    
    $Ip[1] = 0;    $Ip[$T] = 0;    $Bp[1] = 0;    $Bp[$T] = 0;

    for(my $j = 2; $j < $T; $j++){
	$Ip[$j] = 0;
	$Bp[$j] = 0;
	for(my $ill = 0; $ill <= $R; $ill++){ # initialization
	    for(my $jll = 1; $jll <= $T; $jll++){ # initialization
		next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
		if($ill == 0){ # budlge 
		    $Bp[$j] += $p_aref->[$j][$ill][$jll]
		}
		else{ # internal loop
		    $Ip[$j] += $p_aref->[$j][$ill][$jll]
		}
	    }
	}
    }
    
    return (\@Bp, \@Ip);
}



sub calcPj_fast{ 
    my @v  = @{$_[0]};
    my @bv = @{$_[1]};
    my $pf = $_[2];
    
    my (@pb, @pi);
    for(my $j = 2; $j < $T; $j++){ 
	for(my $jll = 0; $jll <= $T; $jll++){ # initialization
	    $pb[$j][$jll] = 0;
	    $pi[$j][$jll] = 0;
	}
    }
    
    # まず、すべてのm,nについて、bulge、internalのボルツマン定数の和を求めておく。
    my @iBol;
    my @bBol;
    for(my $m = 1; $m < $T ; $m++){
	for(my $n = $m+1; $n <= $T; $n++){
	    my $jll = $n - $m - 1; # jll is loop length in sequence (j)
	    next if($jll > $C_MAX_SINGLE_LENGTH);
	    $iBol[$m][$n] = 0;
	    $bBol[$m][$n] = 0;
	    for(my $k = 1; $k < $R; $k++){
		for(my $l = $k+1; $l <= $R; $l++){
		    my $ill = $l - $k - 1; # ill is loop length in sequence (i)
		    #print "TEST:$ill $jll\n";
		    next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
		    
		    my $transit = 0;
		    if($BP{$Rseq[$k]}{$Tseq[$m]} && $BP{$Rseq[$l]}{$Tseq[$n]}){
			# k,m周りのスコア（ターミナル塩基対とミスマッチ）
			my $aroundKM = exp($sTerminalMismatch{"$Tseq[$m]$Rseq[$k]$Tseq[$m+1]$Rseq[$k+1]"} +
					   $sHelixClosing{"$Tseq[$m]$Rseq[$k]"}); 
			my $between  = exp($sSingle[$jll][$ill] + &ScoreSmallLoops($n,$l,$m,$k));  # 順番に注意
			# l,n周りのスコア（ターミナル塩基対とミスマッチ）
			my $aroundLN = exp($sTerminalMismatch{"$Rseq[$l]$Tseq[$n]$Rseq[$l-1]$Tseq[$n-1]"} +
					   $sHelixClosing{"$Rseq[$l]$Tseq[$n]"} + &ScoreBasePair($l, $n));  # これはバックワード変数に加えられる。
			$transit += $aroundKM * $between * $aroundLN;
			
			if($ill > 0 && $jll > 0){ # internal loop
			    $transit *= exp($SWJint[$m+1][$jll]);
			    $transit *= exp($SWIint[$k+1][$ill]);
			    $iBol[$m][$n] += ($v[$k][$m] * $transit * $bv[$l][$n]);
			}
			elsif($ill == 0 && $jll > 0){ # bulge loop in seq.j
			    $transit *= exp($SWJbul[$m+1][$jll]);
			    $bBol[$m][$n] += ($v[$k][$m] * $transit * $bv[$l][$n]);
			}
			
		    }
		}
	    }
	}
    }
    
    # @iBolと@bBolの計算終わり
    # 確率の計算に移る
    for(my $j = 2; $j < $T; $j++){
	for(my $m = 1; $m <= $j - 1; $m++){
	    for(my $n = $j+1; $n <= $T; $n++){
		my $jll = $n - $m - 1; # jll is loop length in sequence (j)
		next if($jll > $C_MAX_SINGLE_LENGTH);
		
		$pb[$j][$jll] += $bBol[$m][$n]/$pf;
		$pi[$j][$jll] += $iBol[$m][$n]/$pf;
		
	    }
	}
    }
    
    my (@pbsum, @pisum);
    $pbsum[1] = 0;    $pisum[1] = 0;
    $pbsum[$T] = 0;    $pisum[$T] = 0;
    for(my $j = 2; $j < $T; $j++){
	$pbsum[$j] = 0;
	$pisum[$j] = 0;
	#my ($pbsum, $pisum);
	for(my $jll = 1; $jll <= min($T-2,$C_MAX_SINGLE_LENGTH); $jll++){
	    #print "j=$j,jlen=$jll:$pb[$j][$jll],$pi[$j][$jll]\n";
	    $pbsum[$j] += $pb[$j][$jll];
	    $pisum[$j] += $pi[$j][$jll];
	}
	#print "$j:b=$pbsum,i=$pisum\n";
    }
    #exit(0);
    return \@pbsum, \@pisum;
}



sub calcPi_fast{ 
    my @v  = @{$_[0]};
    my @bv = @{$_[1]};
    my $pf = $_[2];
    
    my (@pb, @pi);
    for(my $i = 2; $i < $R; $i++){ 
	for(my $ill = 0; $ill <= $R; $ill++){ # initialization
	    $pb[$i][$ill] = 0;
	    $pi[$i][$ill] = 0;
	}
    }
    
    # まず、すべてのk,lについて、bulge、internalのボルツマン定数の和を求めておく。
    my @iBol;
    my @bBol;
    for(my $k = 1; $k < $R ; $k++){
	for(my $l = $k+1; $l <= $R; $l++){
	    my $ill = $l - $k - 1; # ill is loop length in sequence (i)
	    next if($ill > $C_MAX_SINGLE_LENGTH);
	    $iBol[$k][$l] = 0;
	    $bBol[$k][$l] = 0;
	    for(my $m = 1; $m < $T; $m++){
		for(my $n = $m+1; $n <= $T; $n++){
		    my $jll = $n - $m - 1; # jll is loop length in sequence (j)
		    #print "TEST:$ill $jll\n";
		    next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
		    
		    my $transit = 0;
		    if($BP{$Rseq[$k]}{$Tseq[$m]} && $BP{$Rseq[$l]}{$Tseq[$n]}){
			# k,m周りのスコア（ターミナル塩基対とミスマッチ）
			my $aroundKM = exp($sTerminalMismatch{"$Tseq[$m]$Rseq[$k]$Tseq[$m+1]$Rseq[$k+1]"} +
					   $sHelixClosing{"$Tseq[$m]$Rseq[$k]"}); 
			my $between  = exp($sSingle[$jll][$ill] + &ScoreSmallLoops($n,$l,$m,$k));  # 順番に注意
			# l,n周りのスコア（ターミナル塩基対とミスマッチ）
			my $aroundLN = exp($sTerminalMismatch{"$Rseq[$l]$Tseq[$n]$Rseq[$l-1]$Tseq[$n-1]"} +
					   $sHelixClosing{"$Rseq[$l]$Tseq[$n]"} + &ScoreBasePair($l, $n));  # これはバックワード変数に加えられる。
			$transit += $aroundKM * $between * $aroundLN;
			
			if($ill > 0 && $jll > 0){ # internal loop
			    $transit *= exp($SWIint[$k+1][$ill]);
			    $transit *= exp($SWJint[$m+1][$jll]);
			    $iBol[$k][$l] += ($v[$k][$m] * $transit * $bv[$l][$n]);
			}
			elsif($ill > 0 && $jll == 0){ # bulge loop
			    $transit *= exp($SWIbul[$k+1][$ill]);
			    $bBol[$k][$l] += ($v[$k][$m] * $transit * $bv[$l][$n]);
			}
			
		    }
		}
	    }
	}
    }
    
    # @iBolと@bBolの計算終わり
    # 確率の計算に移る
    for(my $i = 2; $i < $R; $i++){
	for(my $k = 1; $k <= $i-1; $k++){
	    for(my $l = $i+1; $l <= $R; $l++){
		my $ill = $l - $k - 1; # ill is loop length in sequence (i)
		next if($ill > $C_MAX_SINGLE_LENGTH);
		
		$pb[$i][$ill] += $bBol[$k][$l]/$pf;
		$pi[$i][$ill] += $iBol[$k][$l]/$pf;
		
	    }
	}
    }
    
    my (@pbsum, @pisum);
    $pbsum[1] = 0;    $pisum[1] = 0;
    $pbsum[$R] = 0;    $pisum[$R] = 0;
    for(my $i = 2; $i < $R; $i++){
	$pbsum[$i] = 0;
	$pisum[$i] = 0;
	#my ($pbsum, $pisum);
	for(my $ill = 1; $ill <= min($R-2,$C_MAX_SINGLE_LENGTH); $ill++){
	    #print "j=$j,jlen=$jll:$pb[$j][$jll],$pi[$j][$jll]\n";
	    $pbsum[$i] += $pb[$i][$ill];
	    $pisum[$i] += $pi[$i][$ill];
	}
	#print "$j:b=$pbsum,i=$pisum\n";
    }
    #exit(0);
    return \@pbsum, \@pisum;
}




sub calcPj{
    my @v  = @{$_[0]};
    my @bv = @{$_[1]};
    my $pf = $_[2];
    
    my @p;
    for(my $j = 2; $j < $T; $j++){ 
	for(my $jll = 0; $jll <= $T; $jll++){ # initialization
	    for(my $ill = 0; $ill <= $R; $ill++){ # initialization
		next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
		$p[$j][$ill][$jll] = 0;
	    }
	}
    }
    for(my $j = 2; $j < $T; $j++){
	my $trains = 0;
	for(my $m = 1; $m <= $j - 1; $m++){
	    for(my $n = $j+1; $n <= $T; $n++){
		my $jll = $n - $m - 1; # jll is loop length in sequence (j)
		for(my $k = 1; $k < $R; $k++){
		    for(my $l = $k+1; $l <= $R; $l++){
			my $ill = $l - $k - 1; # ill is loop length in sequence (i)
			#print "TEST:$ill $jll\n";
			next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
			my $transit = 0;
			
			if($BP{$Rseq[$k]}{$Tseq[$m]} && $BP{$Rseq[$l]}{$Tseq[$n]}){
			    # k,m周りのスコア（ターミナル塩基対とミスマッチ）
			    my $aroundKM = exp($sTerminalMismatch{"$Tseq[$m]$Rseq[$k]$Tseq[$m+1]$Rseq[$k+1]"} +
					       $sHelixClosing{"$Tseq[$m]$Rseq[$k]"}); 
			    my $between  = exp($sSingle[$jll][$ill] + &ScoreSmallLoops($n,$l,$m,$k));  # 順番に注意
			    # l,n周りのスコア（ターミナル塩基対とミスマッチ）
			    my $aroundLN = exp($sTerminalMismatch{"$Rseq[$l]$Tseq[$n]$Rseq[$l-1]$Tseq[$n-1]"} +
					       $sHelixClosing{"$Rseq[$l]$Tseq[$n]"} + &ScoreBasePair($l, $n));  # これはバックワード変数に加えられる。
			    $transit += $aroundKM * $between * $aroundLN;
			    
			    if($ill > 0 && $jll > 0){ # internal loop
				$transit *= exp($SWJint[$m+1][$jll]);
				$transit *= exp($SWIint[$k+1][$ill]);
			    }
			    elsif($ill == 0 && $jll > 0){ # bulge loop
				$transit *= exp($SWIbul[$m+1][$jll]);
			    }
			    
			    
			}
			
			# ここでProbを計算する。
			$p[$j][$ill][$jll] += ($v[$k][$m] * $transit * $bv[$l][$n])/$pf;
		    }
		}
	    }
	    
	}
	
    }
    
    for(my $j = 2; $j < $T; $j++){
	for(my $jll = 0; $jll <= $T; $jll++){     # jll is loop length in sequence (j)
	    for(my $ill = 0; $ill <= $R; $ill++){ # ill is loop length in sequence (i)
		
		next if($ill + $jll > $C_MAX_SINGLE_LENGTH);
		next if($p[$j][$ill][$jll] == 0);
		#print "j=$j,ilen=$ill,jlen=$jll:$p[$j][$ill][$jll]\n";
		
	    }
	}
    }

    return @p;
}




sub dispMat{
    my ($m_aref, $name) = @_;
    print ">$name\n";
    for(my $j = 0; $j <= $#{$m_aref->[0]}; $j++){
	print "\t$j";
    }
    print "\n";
    for(my $i = 0; $i <= $#{$m_aref}; $i++){
	print "$i";
	for(my $j = 0; $j <= $#{$m_aref->[0]}; $j++){
	    my $disp = $m_aref->[$i][$j];
	    if($disp != 0){
		$disp = log($disp);
		printf "\t%.5f", $disp;
	    }
	    elsif($disp == 0){
		print "\t-";
	    }
#	    printf "\t$disp";
	}
	print "\n";
    }
    print "\n";
}



sub setBP{
    my %h;
    
    $h{A}{U} = 1;
    $h{U}{A} = 1;
    $h{G}{C} = 1;
    $h{C}{G} = 1;
    $h{G}{U} = 1;
    $h{U}{G} = 1;
    
    $h{A}{A} = 0;
    $h{A}{C} = 0;
    $h{A}{G} = 0;
    $h{C}{A} = 0;
    $h{C}{C} = 0;
    $h{C}{U} = 0;
    $h{G}{A} = 0;
    $h{G}{G} = 0;
    $h{U}{C} = 0;
    $h{U}{U} = 0;
    
    return %h;
}

#sub max($$){
#    
#    return $_[0] if($_[0] > $_[1]);
#    return $_[1];
#    
#


sub readCONTRAfoldParam{
    my $href = $_[1];
    my $fh = new FileHandle($_[0]) || die;
    while(<$fh>){
	chomp;
	my ($name, $val) = split /\s/;
	$href->{$name} = $val;
    }
    $fh->close();
}

sub setParam{
    # sHairpinLength
    $sHairpinLength[0] = $Param{hairpin_length_at_least_0};
    for (my $i = 1; $i <= $D_MAX_HAIRPIN_LENGTH; $i++){
	$sHairpinLength[$i] = $sHairpinLength[$i-1] + $Param{"hairpin_length_at_least_$i"};
	#print "$i\t$ScoreHairpinLength[$i]\n";
    }
    
    # ScoreHelixClosing
    foreach my $n1 ('A', 'C', 'G', 'U'){
	foreach my $n2 ('A', 'C', 'G', 'U'){
	    $sHelixClosing{"$n1$n2"} = $Param{"helix_closing_$n1$n2"};
	}
    }
    
    # TerminalMismatchScore
    foreach my $n1 ('A', 'C', 'G', 'U'){
	foreach my $n2 ('A', 'C', 'G', 'U'){
	    foreach my $n3 ('A', 'C', 'G', 'U'){
		foreach my $n4 ('A', 'C', 'G', 'U'){
		    $sTerminalMismatch{"$n1$n2$n3$n4"} = $Param{"terminal_mismatch_$n1$n2$n3$n4"};
		}
	    }
	}
    }
    
    # sSingle
    {
	my @tmp_bulge_len;  $tmp_bulge_len[0] = 0;
	for (my $i = 1; $i <= $C_MAX_SINGLE_LENGTH; $i++){
	    $tmp_bulge_len[$i] = $tmp_bulge_len[$i-1] + $Param{"bulge_length_at_least_$i"};
	    #print "bulge$i $tmp_bulge_len[$i]\n";
	}
	my @temp_internal_len;	$temp_internal_len[0] = 0;	$temp_internal_len[1] = 0;
	for (my $i = 2; $i <= $C_MAX_SINGLE_LENGTH; $i++){
	    $temp_internal_len[$i] = $temp_internal_len[$i-1] + $Param{"internal_length_at_least_$i"};
	    #print "internal$i $temp_internal_len[$i]\n";
	}
	my @temp_symm_len;	$temp_symm_len[0] = 0;
	for (my $i = 1; $i <= $C_MAX_SINGLE_LENGTH/2; $i++){
	    $temp_symm_len[$i] = $temp_symm_len[$i-1] + $Param{"internal_symmetric_length_at_least_$i"};
	    #print "symm$i $temp_symm_len[$i]\n";
	}
	my @temp_asymm_len;	$temp_asymm_len[0] = 0;
	for (my $i = 1; $i <= $C_MAX_SINGLE_LENGTH-2; $i++){
	    $temp_asymm_len[$i] = $temp_asymm_len[$i-1] + $Param{"internal_asymmetry_at_least_$i"};
	    #print "asymm$i $temp_asymm_len[$i]\n";
	}
	my @temp_exp_len;
	for (my $i = 0; $i <= 4; $i++){
	    for (my $j = 0; $j <= 4; $j++){
		if($i == 0 || $j == 0){
		    $temp_exp_len[$i][$j] = 0;
		}
		else{
		    $temp_exp_len[$i][$j] = $Param{"internal_explicit_$i\_$j"};
		    #print "$i $j\n";
		}
	    }
	}
	for (my $l1 = 0; $l1 <= $C_MAX_SINGLE_LENGTH; $l1++){
	    for (my $l2 = 0; $l1+$l2 <= $C_MAX_SINGLE_LENGTH; $l2++){
		#$sSingle[$l1][$l2] = 0;
		#next;
		if($l1 == 0 || $l2 == 0){
		    $sSingle[$l1][$l2] = $tmp_bulge_len[$l1+$l2];
		}
		else{
		    $sSingle[$l1][$l2] += $temp_internal_len[$l1+$l2];
		    $sSingle[$l1][$l2] += $temp_symm_len[$l1] if ($l1 == $l2);
		    $sSingle[$l1][$l2] += $temp_asymm_len[abs($l1-$l2)];
		    if($l1 <= 4 && $l2 <= 4){
			my @sort = sort {$a <=> $b} ($l1, $l2);
			my ($i, $j) = ($sort[0], $sort[1]);
			$sSingle[$l1][$l2] += $temp_exp_len[$i][$j];
		    }
		} 
		#print "single $l1 $l2 $sSingle[$l1][$l2]\n"; 
	    } 
	}
    }
    
    # ScoreBasePair
    foreach my $n1 ('A', 'C', 'G', 'U'){
	foreach my $n2 ('A', 'C', 'G', 'U'){
	    my $str = join "", sort ($n1, $n2);
	    $sBasePair{"$n1$n2"} = $Param{"base_pair_$str"};
	}
    }

    # ScoreHelix
    foreach my $n1 ('A', 'C', 'G', 'U'){
	foreach my $n2 ('A', 'C', 'G', 'U'){
	    foreach my $n3 ('A', 'C', 'G', 'U'){
		foreach my $n4 ('A', 'C', 'G', 'U'){
		    my @stacks = sort ("$n1$n2$n3$n4", "$n4$n3$n2$n1");
		    $sStacking{"$n1$n2$n3$n4"} = $Param{"helix_stacking_$stacks[0]"};
		    my $disp = $sStacking{"$n1$n2$n3$n4"};
		    #print "$n1$n2$n3$n4 helix_stacking_$stacks[0]: $disp\n";
		}
	    }
	}
    }

    ## small loops
    # sBulge_1
    foreach my $n ('A', 'C', 'G', 'U'){
	$sBulge_1{$n} = $Param{"bulge_0x1_nucleotides_$n"};
    }
    
    # sInternal_11
    foreach my $n1 ('A', 'C', 'G', 'U'){
	foreach my $n2 ('A', 'C', 'G', 'U'){
	    my $two = join "", sort ($n1, $n2);
	    $sInternal_11{"$n1$n2"} = $Param{"internal_1x1_nucleotides_$two"};
	}
    }
    
    # sExtPair
    $sExtPair   = $Param{external_paired};
    
    # sExtUnpair
    $sExtUnpair = $Param{external_unpaired};
    
    # sDangleL
    foreach my $i1 ('A', 'C', 'G', 'U'){
	foreach my $j1 ('A', 'C', 'G', 'U'){
	    foreach my $i2 ('A', 'C', 'G', 'U'){
		$sDangleL{"$i1$j1$i2"} = $Param{"dangle_left_$i1$j1$i2"};
            }
        }
    }
    
    # sDangleR
    foreach my $i1 ('A', 'C', 'G', 'U'){
	foreach my $j1 ('A', 'C', 'G', 'U'){
	    foreach my $j2 ('A', 'C', 'G', 'U'){
		$sDangleR{"$i1$j1$j2"} = $Param{"dangle_right_$i1$j1$j2"};
            }
        }
    }
    
}

sub ScoreBasePair{
    my ($i, $j) = @_;
    return $sBasePair{"$Rseq[$i]$Tseq[$j]"} + $W{bpp}[$i][$j];
    #    print "TEST:$i\t$j\n";
#    my $pair = "$Rseq[$i]$Tseq[$j]";
#    if($pair eq "GU" || $pair eq "UG"){
#	return $sBasePair{$pair} + $W{w}[$j][4];
#    }
#    else{
#	return $sBasePair{$pair} + $W{w}[$j][0];
#    }

    #return $sBasePair{"$Rseq[$i]$Tseq[$j]"} + $W{w}[$j][0];
}

sub ScoreSmallLoops{
    my ($j, $i, $l, $h) = @_;

    my $l1 = $i - $h - 1;
    my $l2 = $j - $l - 1;
    
    my $s = 0;
    if(   $l1 == 1 && $l2 == 0){
	$s += $sBulge_1{$Rseq[$i-1]};
    }
    elsif($l1 == 0 && $l2 == 1){
	$s += $sBulge_1{$Tseq[$j-1]};
    }
    elsif($l1 == 1 && $l2 == 1){
	$s += $sInternal_11{"$Tseq[$j-1]$Rseq[$i-1]"};
    }
    
    return $s;
}

sub ScoreJunctionB{
    my ($i, $j) = @_;
    return $sHelixClosing{"$Tseq[$i]$Rseq[$j]"} + $sTerminalMismatch{"$Tseq[$i]$Rseq[$j]$Tseq[$i+1]$Rseq[$j-1]"};
}


sub to1basedArray{
    my $str =  $_[0];
    $str =~ tr/T/U/;
    
    my @ar = split "", $str;
    foreach my $n (@ar){
	if($n !~ /[AUGC]/){
	    die "Unexpected nucleotide ($n).\n";
	}
    }
    
    unshift(@ar, "#");
    
    return @ar;
}

sub makeZeroW{ # 常にパラメータ0の時のexpectationを計算する。
    my %h;
    my ($rlen, $tlen) = @_;
    my $n_param = $rlen * $tlen + $rlen * 3 + $tlen * 3;
    for(my $idx = 0; $idx < $n_param; $idx++){
	my $val = 0;
	if($idx < $rlen * $tlen){
	    my ($i, $j) = &idx2ij($idx, $rlen, $tlen);
	    $h{bpp}[$i][$j] = $val;
	}
	else{
	    # type 0 = bulge
	    # type 1 = internal
	    # type 2 = external
	    # type 3 = double strand (non-canonical)
	    my $idx2  = $idx - ($rlen * $tlen);
	    my $type  = $idx2 % 3;
	    my $npos  = int($idx2/3) + 1; # nucleotide position from 1...j and 1..i
	    $h{prof}[$npos][$type] = $val;
	    #print "$npos type=$type idx=$idx idx2=$idx2\n";
	}
    }
    
    return %h;
}


sub idx2ij{
    my ($ind, $r, $t) = @_;
    my $i = int($ind/$t) + 1;
    my $j = ($ind % $t) + 1;
    
    return ($i, $j);
}

sub getLen{
    my $len;

    my %h = @_;
    foreach my $id (keys %h){
        if(!defined $len){
            $len = length($h{$id});
        }
        else{
            my $len2 = length($h{$id});
            if($len != $len2){
                die "Different rbs sequence length ($len:$len2)\n";
            }
        }
    }

    return $len;
}


sub readOneSeq{
    my $seq;

    my $fh = new FileHandle($_[0]) || die;

    chomp ($_ = <$fh>);
    if(!/^>/){
        die "Unexpected fasta header $_\n";
    }
    while(<$fh>){
        chomp;

        if(/^>/){
            die "Multifasta format is prohibitted ($_)\n";
        }

        $seq .= $_;


    }

    $fh->close();


    return $seq;

}

sub readSequence(){
    my ($id, %h);

    my $fh = new FileHandle($_[0]) || die "Can't open $_[0] ($!)\n";;
    while(<$fh>){
        chomp;
        if(/^>(.+)$/){
            $id = $1;
        }
        else{
            $h{$id} .= $_;
        }
    }
    $fh->close();
    
    return %h;
    
}


sub calcWJspan{  # note: 1-based
    my $w_href = $_[0];
    my $type = $_[1];
    my @a;
    for(my $jfm = 1; $jfm <= $T; $jfm++){
	$a[$jfm][1] = $w_href->{prof}[$jfm][$type]; # weight for length 1
    }
    for(my $jfm = 1; $jfm <= $T; $jfm++){
	for(my $len = 2; $len <= $T; $len++){
	    my $jto = $jfm + $len - 1;
	    next if($jto > $T);
	    $a[$jfm][$len] = $a[$jfm][$len-1] + $w_href->{prof}[$jto][$type]; 
	}
    }
    
    if(0){
	for(my $jfm = 1; $jfm <= $T; $jfm++){
	    for(my $len = 1; $len <= $T; $len++){
		my $jto = $jfm + $len - 1;
		#print "$jto $T\n";
		next if($jto > $T);
		#print "ok $type\n";
		print "j=$jfm\tlen=$len\t$a[$jfm][$len]\n" if($type == 2);
	    }
	}
    }
    #exit(0);
    return @a;
}


sub calcWIspan{
    my $w_href = $_[0];
    my $type = $_[1];
    my @a;
    for(my $ifm = $T+1; $ifm <= $T+$R; $ifm++){  # note: 1-based
	$a[$ifm-$T][1] = $w_href->{prof}[$ifm][$type]; # weight for length 1
	#print "$ifm\n";
    }
    for(my $ifm = $T+1; $ifm <= $T+$R; $ifm++){
	for(my $len = 2; $len <= $R; $len++){
	    my $ito = $ifm + $len - 1;
	    next if($ito > $T + $R);
	    $a[$ifm-$T][$len] = $a[$ifm-$T][$len-1] + $w_href->{prof}[$ito][$type]; 
	    #print "TEST:i=$ifm-$T\trlen=$len\t($a[$ifm-$T][$len]) $type\n";
	}
    }
    
    if(0 && $type == 2){
	for(my $ifm = 1; $ifm <= $R; $ifm++){
	    for(my $len = 1; $len <= $R; $len++){
		my $ito = $ifm + $len - 1;
		#print "ok $ifm-$ito $R\n";
		next if($ito > $R);
		print "i=$ifm\trlen=$len\t($a[$ifm][$len])\n" if($type == 2);
	    }
	}
	exit(0);
    }
    return @a;
}


sub min($$){

    return $_[0] if($_[0] < $_[1]);
    return $_[1];

}

